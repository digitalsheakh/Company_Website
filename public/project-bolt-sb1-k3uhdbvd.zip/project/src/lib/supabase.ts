import { createClient } from '@supabase/supabase-js';
import type { Database } from '../types/supabase';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey);

export async function registerTeacher(userData: {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  phone: string;
  qualifications: string;
  subjects: string[];
  experience: string;
}) {
  try {
    // 1. Sign up the user with Supabase Auth
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email: userData.email,
      password: userData.password,
      options: {
        data: {
          user_type: 'teacher',
          first_name: userData.firstName,
          last_name: userData.lastName
        }
      }
    });

    if (authError) throw authError;
    if (!authData.user) throw new Error('No user data returned');

    // 2. Insert the teacher profile data
    const { error: profileError } = await supabase
      .from('teachers')
      .insert({
        id: authData.user.id,
        first_name: userData.firstName,
        last_name: userData.lastName,
        phone: userData.phone,
        qualifications: userData.qualifications,
        subjects: userData.subjects,
        experience: userData.experience,
        status: 'pending'
      });

    if (profileError) {
      console.error('Error creating teacher profile:', profileError);
      throw profileError;
    }

    return { user: authData.user, error: null };
  } catch (error: any) {
    console.error('Error in registerTeacher:', error);
    return { user: null, error: error.message };
  }
}