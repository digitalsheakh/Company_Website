import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center">
              <BookOpen className="h-8 w-8 text-blue-400" />
              <span className="ml-2 text-xl font-bold">TeachSupply</span>
            </div>
            <p className="mt-4 text-gray-300">
              Connecting qualified teachers with schools that need them most.
            </p>
            <div className="flex space-x-4 mt-6">
              <a href="#" className="text-gray-400 hover:text-white">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">For Teachers</h3>
            <ul className="space-y-2">
              <li><Link to="/jobs" className="text-gray-300 hover:text-white">Find Jobs</Link></li>
              <li><Link to="/register" className="text-gray-300 hover:text-white">Create Profile</Link></li>
              <li><Link to="#" className="text-gray-300 hover:text-white">Resources</Link></li>
              <li><Link to="#" className="text-gray-300 hover:text-white">FAQ</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">For Schools</h3>
            <ul className="space-y-2">
              <li><Link to="#" className="text-gray-300 hover:text-white">Post a Job</Link></li>
              <li><Link to="#" className="text-gray-300 hover:text-white">Find Teachers</Link></li>
              <li><Link to="#" className="text-gray-300 hover:text-white">Pricing</Link></li>
              <li><Link to="#" className="text-gray-300 hover:text-white">Success Stories</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-2">
              <li className="text-gray-300">Email: info@teachsupply.com</li>
              <li className="text-gray-300">Phone: +44 123 456 7890</li>
              <li className="text-gray-300">Address: 123 Education St, London</li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-12 pt-8">
          <p className="text-center text-gray-300">
            &copy; {new Date().getFullYear()} TeachSupply. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;