import React, { useState } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  Briefcase, 
  User, 
  Settings, 
  LogOut,
  Menu,
  X,
  LayoutDashboard,
  ChevronDown,
  GraduationCap,
  DollarSign,
  Bell
} from 'lucide-react';
import { useAuthStore } from '../../store/authStore';

const TeacherLayout = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { signOut } = useAuthStore();
  
  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };
  
  const isActive = (path: string) => {
    return location.pathname === path || location.pathname.startsWith(`${path}/`);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Navigation */}
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Link to="/teacher" className="flex items-center">
                <GraduationCap className="h-8 w-8 text-blue-600" />
                <span className="ml-2 text-xl font-bold text-gray-900">GoTeach</span>
              </Link>
              
              <div className="hidden md:ml-8 md:flex md:space-x-4">
                <Link
                  to="/teacher"
                  className={`px-3 py-2 rounded-md text-sm font-medium ${
                    isActive('/teacher')
                      ? 'text-blue-600'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  Dashboard
                </Link>
                <Link
                  to="/teacher/jobs"
                  className={`px-3 py-2 rounded-md text-sm font-medium ${
                    isActive('/teacher/jobs')
                      ? 'text-blue-600'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  Find Jobs
                </Link>
                <Link
                  to="/teacher/applications"
                  className={`px-3 py-2 rounded-md text-sm font-medium ${
                    isActive('/teacher/applications')
                      ? 'text-blue-600'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  My Applications
                </Link>
                <Link
                  to="/teacher/payments"
                  className={`px-3 py-2 rounded-md text-sm font-medium ${
                    isActive('/teacher/payments')
                      ? 'text-blue-600'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  Payments
                </Link>
              </div>
            </div>
            
            <div className="flex items-center">
              {/* Notifications */}
              <div className="relative ml-3">
                <button
                  className="p-1 rounded-full text-gray-400 hover:text-gray-500 focus:outline-none"
                  onClick={() => setNotificationsOpen(!notificationsOpen)}
                >
                  <span className="sr-only">View notifications</span>
                  <Bell className="h-6 w-6" />
                </button>
              </div>
              
              {/* Profile dropdown */}
              <div className="relative ml-3">
                <button
                  className="flex items-center max-w-xs rounded-full focus:outline-none"
                  onClick={() => setProfileOpen(!profileOpen)}
                >
                  <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center">
                    <User className="h-5 w-5 text-gray-500" />
                  </div>
                  <ChevronDown className="ml-1 h-4 w-4 text-gray-500" />
                </button>

                {profileOpen && (
                  <div className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-50">
                    <div className="py-1">
                      <Link
                        to="/teacher/settings"
                        className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                        onClick={() => setProfileOpen(false)}
                      >
                        Settings
                      </Link>
                      <button
                        onClick={handleSignOut}
                        className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      >
                        Sign out
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Mobile menu button */}
              <div className="flex items-center md:hidden ml-3">
                <button
                  className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none"
                  onClick={() => setSidebarOpen(!sidebarOpen)}
                >
                  <span className="sr-only">Open main menu</span>
                  {sidebarOpen ? (
                    <X className="block h-6 w-6" />
                  ) : (
                    <Menu className="block h-6 w-6" />
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {sidebarOpen && (
          <div className="md:hidden">
            <div className="pt-2 pb-3 space-y-1">
              <Link
                to="/teacher"
                className={`block px-3 py-2 rounded-md text-base font-medium ${
                  isActive('/teacher')
                    ? 'bg-blue-50 text-blue-600'
                    : 'text-gray-500 hover:bg-gray-50 hover:text-gray-700'
                }`}
                onClick={() => setSidebarOpen(false)}
              >
                Dashboard
              </Link>
              <Link
                to="/teacher/jobs"
                className={`block px-3 py-2 rounded-md text-base font-medium ${
                  isActive('/teacher/jobs')
                    ? 'bg-blue-50 text-blue-600'
                    : 'text-gray-500 hover:bg-gray-50 hover:text-gray-700'
                }`}
                onClick={() => setSidebarOpen(false)}
              >
                Find Jobs
              </Link>
              <Link
                to="/teacher/applications"
                className={`block px-3 py-2 rounded-md text-base font-medium ${
                  isActive('/teacher/applications')
                    ? 'bg-blue-50 text-blue-600'
                    : 'text-gray-500 hover:bg-gray-50 hover:text-gray-700'
                }`}
                onClick={() => setSidebarOpen(false)}
              >
                My Applications
              </Link>
              <Link
                to="/teacher/payments"
                className={`block px-3 py-2 rounded-md text-base font-medium ${
                  isActive('/teacher/payments')
                    ? 'bg-blue-50 text-blue-600'
                    : 'text-gray-500 hover:bg-gray-50 hover:text-gray-700'
                }`}
                onClick={() => setSidebarOpen(false)}
              >
                Payments
              </Link>
              <Link
                to="/teacher/settings"
                className={`block px-3 py-2 rounded-md text-base font-medium ${
                  isActive('/teacher/settings')
                    ? 'bg-blue-50 text-blue-600'
                    : 'text-gray-500 hover:bg-gray-50 hover:text-gray-700'
                }`}
                onClick={() => setSidebarOpen(false)}
              >
                Settings
              </Link>
            </div>
          </div>
        )}
      </nav>

      {/* Main content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Outlet />
      </main>
    </div>
  );
};

export default TeacherLayout;