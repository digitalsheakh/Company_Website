import React from 'react';
import { Link } from 'react-router-dom';
import { GraduationCap } from 'lucide-react';

const AuthNav = () => {
  return (
    <nav className="absolute top-0 left-0 right-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2 text-white hover:text-gray-200 transition-colors duration-200">
            <GraduationCap className="h-8 w-8 text-blue-400" />
            <span className="text-xl font-bold">GoTeach</span>
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default AuthNav;