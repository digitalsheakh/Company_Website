import React, { useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import AdminLoginPage from './pages/admin/LoginPage';
import AdminDashboard from './pages/admin/Dashboard';
import AdminTeachers from './pages/admin/Teachers';
import AdminSchools from './pages/admin/Schools';
import AdminJobs from './pages/admin/Jobs';
import AdminSettings from './pages/admin/Settings';
import AdminLayout from './components/admin/AdminLayout';
import TeacherProfile from './pages/admin/TeacherProfile';
import AdminRoute from './components/AdminRoute';
import SchoolRoute from './components/SchoolRoute';
import TeacherRoute from './components/TeacherRoute';
import SchoolLayout from './components/school/SchoolLayout';
import TeacherLayout from './components/teacher/TeacherLayout';
import SchoolDashboard from './pages/school/Dashboard';
import JobsList from './pages/school/jobs/JobsList';
import JobForm from './pages/school/jobs/JobForm';
import PaymentsList from './pages/school/jobs/PaymentsList';
import TeacherDashboard from './pages/teacher/Dashboard';
import TeacherJobs from './pages/teacher/Jobs';
import TeacherApplications from './pages/teacher/Applications';
import TeacherPayments from './pages/teacher/Payments';
import TeacherSettings from './pages/teacher/Settings';
import { useAuthStore } from './store/authStore';

function App() {
  const { checkUser, user, userType } = useAuthStore();

  useEffect(() => {
    checkUser();
  }, [checkUser]);

  // Redirect authenticated users to their respective dashboards
  if (user) {
    switch (userType) {
      case 'teacher':
        return (
          <Routes>
            <Route 
              path="/teacher" 
              element={
                <TeacherRoute>
                  <TeacherLayout />
                </TeacherRoute>
              }
            >
              <Route index element={<TeacherDashboard />} />
              <Route path="jobs" element={<TeacherJobs />} />
              <Route path="applications" element={<TeacherApplications />} />
              <Route path="payments" element={<TeacherPayments />} />
              <Route path="settings" element={<TeacherSettings />} />
            </Route>
            <Route path="*" element={<Navigate to="/teacher" replace />} />
          </Routes>
        );

      case 'school':
        return (
          <Routes>
            <Route
              path="/school"
              element={
                <SchoolRoute>
                  <SchoolLayout />
                </SchoolRoute>
              }
            >
              <Route index element={<SchoolDashboard />} />
              <Route path="jobs" element={<JobsList />} />
              <Route path="jobs/new" element={<JobForm />} />
              <Route path="jobs/:id/edit" element={<JobForm />} />
              <Route path="payments" element={<PaymentsList />} />
            </Route>
            <Route path="*" element={<Navigate to="/school" replace />} />
          </Routes>
        );

      case 'admin':
        return (
          <Routes>
            <Route path="/admin/login" element={<AdminLoginPage />} />
            <Route 
              path="/admin" 
              element={
                <AdminRoute>
                  <AdminLayout />
                </AdminRoute>
              }
            >
              <Route index element={<AdminDashboard />} />
              <Route path="teachers" element={<AdminTeachers />} />
              <Route path="teachers/:id" element={<TeacherProfile />} />
              <Route path="schools" element={<AdminSchools />} />
              <Route path="jobs" element={<AdminJobs />} />
              <Route path="settings" element={<AdminSettings />} />
            </Route>
            <Route path="*" element={<Navigate to="/admin" replace />} />
          </Routes>
        );
    }
  }

  // Routes for non-authenticated users
  return (
    <div className="flex flex-col min-h-screen">
      <Routes>
        <Route path="/admin/login" element={<AdminLoginPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        
        {/* Public routes with Navbar and Footer */}
        <Route
          path="*"
          element={
            <>
              <Navbar />
              <main className="flex-grow">
                <Routes>
                  <Route index element={<HomePage />} />
                  <Route path="/about" element={<AboutPage />} />
                  <Route path="/contact" element={<ContactPage />} />
                </Routes>
              </main>
              <Footer />
            </>
          }
        />
      </Routes>
    </div>
  );
}

export default App;