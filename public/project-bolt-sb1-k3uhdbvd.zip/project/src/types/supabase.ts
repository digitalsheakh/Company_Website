export interface Database {
  public: {
    Tables: {
      documents: {
        Row: {
          id: string;
          teacher_id: string;
          type: 'identity' | 'dbs' | 'ni_number' | 'cv';
          file_url: string;
          status: 'pending' | 'verified' | 'rejected';
          notes: string | null;
          created_at: string;
          updated_at: string;
          verified_at: string | null;
          verified_by: string | null;
        };
        Insert: {
          id?: string;
          teacher_id: string;
          type: 'identity' | 'dbs' | 'ni_number' | 'cv';
          file_url: string;
          status?: 'pending' | 'verified' | 'rejected';
          notes?: string | null;
          created_at?: string;
          updated_at?: string;
          verified_at?: string | null;
          verified_by?: string | null;
        };
        Update: {
          id?: string;
          teacher_id?: string;
          type?: 'identity' | 'dbs' | 'ni_number' | 'cv';
          file_url?: string;
          status?: 'pending' | 'verified' | 'rejected';
          notes?: string | null;
          created_at?: string;
          updated_at?: string;
          verified_at?: string | null;
          verified_by?: string | null;
        };
      };
      schools: {
        Row: {
          id: string;
          name: string;
          email: string;
          phone: string | null;
          position: string;
          type: string;
          location: string;
          status: 'pending' | 'verified' | 'rejected';
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          name: string;
          email: string;
          phone?: string | null;
          position: string;
          type: string;
          location: string;
          status?: 'pending' | 'verified' | 'rejected';
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          email?: string;
          phone?: string | null;
          position?: string;
          type?: string;
          location?: string;
          status?: 'pending' | 'verified' | 'rejected';
          created_at?: string;
          updated_at?: string;
        };
      };
      teachers: {
        Row: {
          id: string;
          email: string;
          first_name: string;
          last_name: string;
          phone: string | null;
          qualifications: string | null;
          subjects: string[] | null;
          experience: string | null;
          status: 'pending' | 'verified' | 'rejected';
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email: string;
          first_name: string;
          last_name: string;
          phone?: string | null;
          qualifications?: string | null;
          subjects?: string[] | null;
          experience?: string | null;
          status?: 'pending' | 'verified' | 'rejected';
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          email?: string;
          first_name?: string;
          last_name?: string;
          phone?: string | null;
          qualifications?: string | null;
          subjects?: string[] | null;
          experience?: string | null;
          status?: 'pending' | 'verified' | 'rejected';
          created_at?: string;
          updated_at?: string;
        };
      };
      jobs: {
        Row: {
          id: string;
          school_id: string;
          title: string;
          description: string;
          type: string;
          salary_range: string;
          location: string;
          status: 'pending_approval' | 'active' | 'completed' | 'rejected' | 'archived';
          applications: number;
          created_at: string;
          updated_at: string;
          expires_at: string;
        };
        Insert: {
          id?: string;
          school_id: string;
          title: string;
          description: string;
          type: string;
          salary_range: string;
          location: string;
          status?: 'pending_approval' | 'active' | 'completed' | 'rejected' | 'archived';
          applications?: number;
          created_at?: string;
          updated_at?: string;
          expires_at: string;
        };
        Update: {
          id?: string;
          school_id?: string;
          title?: string;
          description?: string;
          type?: string;
          salary_range?: string;
          location?: string;
          status?: 'pending_approval' | 'active' | 'completed' | 'rejected' | 'archived';
          applications?: number;
          created_at?: string;
          updated_at?: string;
          expires_at?: string;
        };
      };
      job_applications: {
        Row: {
          id: string;
          job_id: string;
          teacher_id: string;
          school_id: string;
          status: 'pending' | 'accepted' | 'rejected';
          notes: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          job_id: string;
          teacher_id: string;
          school_id: string;
          status?: 'pending' | 'accepted' | 'rejected';
          notes?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          job_id?: string;
          teacher_id?: string;
          school_id?: string;
          status?: 'pending' | 'accepted' | 'rejected';
          notes?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
    };
  };
}