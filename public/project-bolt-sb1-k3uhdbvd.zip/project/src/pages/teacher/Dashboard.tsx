import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Briefcase, 
  DollarSign, 
  Clock, 
  CheckCircle, 
  XCircle, 
  Search, 
  MapPin, 
  Calendar,
  FileText,
  AlertCircle,
  Upload,
  Shield
} from 'lucide-react';
import { supabase } from '../../lib/supabase';

const TeacherDashboard = () => {
  const [stats, setStats] = useState({
    activeApplications: 0,
    acceptedApplications: 0,
    totalEarnings: 0,
    pendingPayments: 0
  });
  
  const [recentJobs, setRecentJobs] = useState<any[]>([]);
  const [recentApplications, setRecentApplications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [verificationStatus, setVerificationStatus] = useState<'pending' | 'verified' | 'rejected'>('pending');

  // Required documents and their status
  const [documents, setDocuments] = useState([
    {
      id: 'identity',
      name: 'Proof of Identity',
      description: 'Valid government-issued photo ID (passport or driver\'s license)',
      requirements: ['Must be current and clearly legible'],
      status: 'pending'
    },
    {
      id: 'dbs',
      name: 'Enhanced DBS Certificate',
      description: 'Enhanced Disclosure and Barring Service Certificate',
      requirements: [
        'Must be dated within the last 12 months',
        'All pages of the certificate required',
        'Must be the original Enhanced DBS, not a basic check'
      ],
      status: 'pending'
    },
    {
      id: 'ni',
      name: 'National Insurance Number',
      description: 'Official HMRC document or NI card',
      requirements: [
        'Document must clearly display your full name and NI number',
        'Must be an official HMRC document or NI card'
      ],
      status: 'pending'
    },
    {
      id: 'cv',
      name: 'Professional CV',
      description: 'Detailed curriculum vitae with references',
      requirements: [
        'Include complete work history in education sector',
        'Minimum of 2 professional references with current contact details',
        'References must be from previous educational employers'
      ],
      status: 'pending'
    }
  ]);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error('No user found');

      // Fetch teacher profile to get verification status
      const { data: teacherData, error: teacherError } = await supabase
        .from('teachers')
        .select('status')
        .eq('id', user.id)
        .single();

      if (teacherError) throw teacherError;

      if (teacherData) {
        setVerificationStatus(teacherData.status as 'pending' | 'verified' | 'rejected');
      }

      // Fetch applications stats
      const { data: applications, error: applicationsError } = await supabase
        .from('job_applications')
        .select(`
          id,
          status,
          created_at,
          job:jobs!inner(
            id,
            title,
            type,
            salary_range,
            location,
            work_date,
            school:schools!inner(
              id,
              name
            )
          )
        `)
        .eq('teacher_id', user.id)
        .order('created_at', { ascending: false });

      if (applicationsError) throw applicationsError;

      // Set recent applications
      setRecentApplications(applications?.slice(0, 5) || []);

      // Calculate stats
      const activeApps = applications?.filter(app => app.status === 'pending').length || 0;
      const acceptedApps = applications?.filter(app => app.status === 'accepted').length || 0;
      
      // Calculate earnings (simplified)
      const totalEarnings = applications
        ?.filter(app => app.status === 'accepted')
        .reduce((sum, app) => {
          const rate = parseInt(app.job.salary_range?.replace(/[^0-9]/g, '')) || 0;
          return sum + rate;
        }, 0) || 0;

      setStats({
        activeApplications: activeApps,
        acceptedApplications: acceptedApps,
        totalEarnings,
        pendingPayments: acceptedApps * 100 // Simplified
      });

      // Fetch recent available jobs
      const { data: jobs, error: jobsError } = await supabase
        .from('jobs')
        .select(`
          id,
          title,
          type,
          salary_range,
          location,
          created_at,
          school:schools!inner(
            id,
            name
          )
        `)
        .eq('status', 'active')
        .order('created_at', { ascending: false })
        .limit(5);

      if (jobsError) throw jobsError;

      setRecentJobs(jobs || []);
    } catch (err: any) {
      console.error('Error fetching dashboard data:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleUploadDocument = async (documentId: string) => {
    // This would be implemented to handle document uploads
    console.log('Uploading document:', documentId);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 bg-red-100 text-red-700 rounded-lg">
        <p>Error loading dashboard: {error}</p>
      </div>
    );
  }

  return (
    <div>
      {/* Document Verification Section - Show only if not verified */}
      {verificationStatus !== 'verified' && (
        <div className="bg-gradient-to-r from-yellow-600 to-orange-600 rounded-xl p-8 mb-8 text-white">
          <div className="flex items-start">
            <div className="flex-shrink-0">
              <AlertCircle className="h-6 w-6" />
            </div>
            <div className="ml-3">
              <h3 className="text-lg font-medium">Account Verification Required</h3>
              <p className="mt-2 text-sm">
                Please submit the following documents to complete your profile verification. This helps us maintain high standards and ensure safety for all users.
              </p>
            </div>
          </div>
        </div>
      )}

      {verificationStatus !== 'verified' && (
        <div className="bg-white rounded-xl shadow-sm overflow-hidden mb-8">
          <div className="p-6 border-b border-gray-100">
            <div className="flex items-center">
              <Shield className="h-6 w-6 text-blue-600" />
              <h2 className="ml-3 text-xl font-semibold text-gray-900">Required Documents</h2>
            </div>
          </div>

          <div className="divide-y divide-gray-100">
            {documents.map((doc) => (
              <div key={doc.id} className="p-6">
                <div className="flex items-start">
                  <div className="flex-1">
                    <div className="flex items-center">
                      <FileText className="h-5 w-5 text-gray-400" />
                      <h3 className="ml-2 text-lg font-medium text-gray-900">{doc.name}</h3>
                      <span className={`ml-3 px-2.5 py-0.5 text-xs font-medium rounded-full ${
                        doc.status === 'verified' ? 'bg-green-100 text-green-800' :
                        doc.status === 'rejected' ? 'bg-red-100 text-red-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {doc.status.charAt(0).toUpperCase() + doc.status.slice(1)}
                      </span>
                    </div>
                    <p className="mt-2 text-sm text-gray-600">{doc.description}</p>
                    <ul className="mt-2 space-y-1">
                      {doc.requirements.map((req, index) => (
                        <li key={index} className="flex items-start text-sm text-gray-500">
                          <span className="flex-shrink-0 mr-1.5">•</span>
                          {req}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="ml-6">
                    <button
                      onClick={() => handleUploadDocument(doc.id)}
                      className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      Upload
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-gray-50 px-6 py-4">
            <div className="text-sm text-gray-500">
              <p>
                <span className="font-medium text-gray-900">Note:</span>{' '}
                All documents must be submitted in clear, high-resolution PDF or image format. Your teacher account will remain pending until all documents are verified by our admin team.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl p-8 mb-8 text-white">
        <h1 className="text-3xl font-bold mb-2">Welcome Back!</h1>
        <p className="text-blue-100 mb-6">Find your next teaching opportunity from our curated list of positions.</p>
        <Link
          to="/teacher/jobs"
          className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-blue-700 bg-white hover:bg-blue-50 transition-all duration-200"
        >
          <Briefcase className="mr-2 h-5 w-5" />
          Browse Available Jobs
        </Link>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-blue-100">
              <Briefcase className="h-6 w-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">Active Applications</p>
              <h3 className="text-xl font-semibold text-gray-900">{stats.activeApplications}</h3>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-green-100">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">Accepted Jobs</p>
              <h3 className="text-xl font-semibold text-gray-900">{stats.acceptedApplications}</h3>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-yellow-100">
              <DollarSign className="h-6 w-6 text-yellow-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">Total Earnings</p>
              <h3 className="text-xl font-semibold text-gray-900">£{stats.totalEarnings}</h3>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-purple-100">
              <Clock className="h-6 w-6 text-purple-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">Pending Payments</p>
              <h3 className="text-xl font-semibold text-gray-900">£{stats.pendingPayments}</h3>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Jobs */}
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="p-6 border-b border-gray-100">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold text-gray-900">Recent Jobs</h2>
              <Link to="/teacher/jobs" className="text-blue-600 hover:text-blue-700 text-sm font-medium">
                View All Jobs
              </Link>
            </div>
          </div>
          
          <div className="divide-y divide-gray-100">
            {recentJobs.map((job) => (
              <Link
                key={job.id}
                to={`/teacher/jobs/${job.id}`}
                className="block p-6 hover:bg-gray-50 transition-colors duration-200"
              >
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-lg font-medium text-gray-900">{job.title}</h3>
                  <span className="px-2.5 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                    {job.type}
                  </span>
                </div>
                <p className="text-sm text-gray-600 mb-3">{job.school.name}</p>
                <div className="flex items-center text-sm text-gray-500 space-x-4">
                  <span className="flex items-center">
                    <MapPin className="h-4 w-4 mr-1" />
                    {job.location}
                  </span>
                  <span className="flex items-center">
                    <DollarSign className="h-4 w-4 mr-1" />
                    {job.salary_range}
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Recent Applications */}
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="p-6 border-b border-gray-100">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold text-gray-900">Recent Applications</h2>
              <Link to="/teacher/applications" className="text-blue-600 hover:text-blue-700 text-sm font-medium">
                View All Applications
              </Link>
            </div>
          </div>
          
          <div className="divide-y divide-gray-100">
            {recentApplications.map((application) => (
              <div key={application.id} className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-lg font-medium text-gray-900">{application.job.title}</h3>
                  <span className={`px-2.5 py-1 text-xs font-medium rounded-full ${
                    application.status === 'accepted' ? 'bg-green-100 text-green-800' :
                    application.status === 'rejected' ? 'bg-red-100 text-red-800' :
                    'bg-yellow-100 text-yellow-800'
                  }`}>
                    {application.status.charAt(0).toUpperCase() + application.status.slice(1)}
                  </span>
                </div>
                <p className="text-sm text-gray-600 mb-3">{application.job.school.name}</p>
                <div className="flex items-center text-sm text-gray-500 space-x-4">
                  <span className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    Applied {new Date(application.created_at).toLocaleDateString()}
                  </span>
                  <span className="flex items-center">
                    <MapPin className="h-4 w-4 mr-1" />
                    {application.job.location}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TeacherDashboard;