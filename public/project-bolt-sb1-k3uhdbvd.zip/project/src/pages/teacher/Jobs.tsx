import React, { useState, useEffect } from 'react';
import { Search, Filter, MapPin, DollarSign, Calendar, Briefcase } from 'lucide-react';
import { supabase } from '../../lib/supabase';

const TeacherJobs = () => {
  const [jobs, setJobs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filterType, setFilterType] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [applications, setApplications] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetchJobs();
    fetchUserApplications();
  }, []);

  const fetchJobs = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('jobs')
        .select(`
          *,
          school:schools!inner(
            id,
            name,
            location
          )
        `)
        .eq('status', 'active')
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Filter out any jobs with incomplete data
      const validJobs = data?.filter(job => job.school && job.school.name) || [];
      setJobs(validJobs);
    } catch (err: any) {
      console.error('Error fetching jobs:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchUserApplications = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error('No user found');

      const { data, error } = await supabase
        .from('job_applications')
        .select('job_id')
        .eq('teacher_id', user.id);

      if (error) throw error;

      setApplications(new Set(data?.map(app => app.job_id)));
    } catch (err: any) {
      console.error('Error fetching applications:', err);
    }
  };

  const handleApply = async (jobId: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error('No user found');

      const job = jobs.find(j => j.id === jobId);
      if (!job) throw new Error('Job not found');

      const { error } = await supabase
        .from('job_applications')
        .insert([{
          job_id: jobId,
          teacher_id: user.id,
          school_id: job.school_id,
          status: 'pending'
        }]);

      if (error) throw error;

      // Update local state
      setApplications(prev => new Set([...prev, jobId]));
    } catch (err: any) {
      console.error('Error applying for job:', err);
      setError('Failed to apply for job. Please try again.');
    }
  };

  // Filter jobs based on type and search query
  const filteredJobs = jobs.filter(job => {
    const matchesType = filterType === 'all' || job.type === filterType;
    const matchesSearch = 
      job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.school.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.location.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesType && matchesSearch;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 bg-red-100 text-red-700 rounded-lg">
        <p>Error loading jobs: {error}</p>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Available Jobs</h2>
      </div>

      {/* Filters */}
      <div className="bg-white shadow rounded-lg mb-6">
        <div className="p-4 border-b border-gray-200 sm:flex sm:items-center sm:justify-between">
          <div className="flex items-center">
            <Filter className="h-5 w-5 text-gray-400 mr-2" />
            <span className="text-sm font-medium text-gray-700">Filter by type:</span>
            <div className="ml-2 space-x-2">
              <button
                onClick={() => setFilterType('all')}
                className={`px-3 py-1 rounded-full text-xs font-medium ${
                  filterType === 'all' ? 'bg-gray-200 text-gray-800' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setFilterType('full-time')}
                className={`px-3 py-1 rounded-full text-xs font-medium ${
                  filterType === 'full-time' ? 'bg-blue-200 text-blue-800' : 'bg-blue-100 text-blue-600 hover:bg-blue-200'
                }`}
              >
                Full Time
              </button>
              <button
                onClick={() => setFilterType('part-time')}
                className={`px-3 py-1 rounded-full text-xs font-medium ${
                  filterType === 'part-time' ? 'bg-green-200 text-green-800' : 'bg-green-100 text-green-600 hover:bg-green-200'
                }`}
              >
                Part Time
              </button>
              <button
                onClick={() => setFilterType('temporary')}
                className={`px-3 py-1 rounded-full text-xs font-medium ${
                  filterType === 'temporary' ? 'bg-yellow-200 text-yellow-800' : 'bg-yellow-100 text-yellow-600 hover:bg-yellow-200'
                }`}
              >
                Temporary
              </button>
            </div>
          </div>
          
          <div className="mt-3 sm:mt-0 relative rounded-md shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search jobs..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
            />
          </div>
        </div>
      </div>

      {/* Jobs Grid */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {filteredJobs.map((job) => (
          <div key={job.id} className="bg-white shadow rounded-lg overflow-hidden hover:shadow-lg transition-shadow duration-200">
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">{job.title}</h3>
                  <p className="text-sm text-gray-600">{job.school.name}</p>
                </div>
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                  job.type === 'full-time' ? 'bg-blue-100 text-blue-800' :
                  job.type === 'part-time' ? 'bg-green-100 text-green-800' :
                  'bg-yellow-100 text-yellow-800'
                }`}>
                  {job.type.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                </span>
              </div>
              
              <div className="space-y-3 mb-6">
                <div className="flex items-center text-sm text-gray-500">
                  <MapPin className="h-4 w-4 mr-2" />
                  {job.location}
                </div>
                <div className="flex items-center text-sm text-gray-500">
                  <DollarSign className="h-4 w-4 mr-2" />
                  {job.salary_range}
                </div>
                <div className="flex items-center text-sm text-gray-500">
                  <Calendar className="h-4 w-4 mr-2" />
                  Start Date: {new Date(job.work_date).toLocaleDateString()}
                </div>
              </div>
              
              <div className="text-sm text-gray-600 mb-6">
                {job.description.length > 150 
                  ? `${job.description.substring(0, 150)}...` 
                  : job.description}
              </div>
              
              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-500">
                  Posted {new Date(job.created_at).toLocaleDateString()}
                </div>
                {applications.has(job.id) ? (
                  <span className="inline-flex items-center px-3 py-1 rounded-md text-sm font-medium bg-gray-100 text-gray-800">
                    Applied
                  </span>
                ) : (
                  <button
                    onClick={() => handleApply(job.id)}
                    className="inline-flex items-center px-3 py-1 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    <Briefcase className="h-4 w-4 mr-2" />
                    Apply Now
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredJobs.length === 0 && (
        <div className="text-center py-12 bg-white rounded-lg shadow">
          <Briefcase className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No Jobs Found</h3>
          <p className="mt-1 text-sm text-gray-500">
            {searchQuery || filterType !== 'all'
              ? 'Try adjusting your filters or search terms'
              : 'Check back later for new job opportunities'}
          </p>
        </div>
      )}
    </div>
  );
};

export default TeacherJobs;