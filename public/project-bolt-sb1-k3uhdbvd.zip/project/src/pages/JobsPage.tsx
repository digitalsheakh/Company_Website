import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, MapPin, Clock, Filter, X, DollarSign, Briefcase } from 'lucide-react';

const JobsPage = () => {
  const [filters, setFilters] = useState({
    jobType: [],
    subject: [],
    experience: [],
  });
  
  const [showFilters, setShowFilters] = useState(false);
  
  const toggleFilter = (category, value) => {
    setFilters(prev => {
      const updated = { ...prev };
      if (updated[category].includes(value)) {
        updated[category] = updated[category].filter(item => item !== value);
      } else {
        updated[category] = [...updated[category], value];
      }
      return updated;
    });
  };
  
  const clearFilters = () => {
    setFilters({
      jobType: [],
      subject: [],
      experience: [],
    });
  };
  
  // Mock job data
  const jobs = [
    {
      id: 1,
      title: 'Mathematics Teacher',
      school: 'Oakridge Secondary School',
      location: 'London, UK',
      type: 'Full-time',
      salary: '£150 - £180 per day',
      posted: '2 days ago',
      description: 'Experienced mathematics teacher needed for long-term position covering KS3 and KS4 curriculum.',
      image: 'https://images.unsplash.com/photo-1577896851231-70ef18881754?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80'
    },
    {
      id: 2,
      title: 'English Literature Teacher',
      school: 'St. Mary\'s Academy',
      location: 'Manchester, UK',
      type: 'Part-time',
      salary: '£130 - £150 per day',
      posted: '1 day ago',
      description: 'Part-time English teacher required for Year 10 and 11 classes, focusing on GCSE preparation.',
      image: 'https://images.unsplash.com/photo-1577896852618-3b29ee2f433e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80'
    },
    {
      id: 3,
      title: 'Science Teacher (Biology)',
      school: 'Westfield Comprehensive',
      location: 'Birmingham, UK',
      type: 'Temporary',
      salary: '£140 - £160 per day',
      posted: '3 days ago',
      description: 'Biology specialist needed for 6-week cover starting immediately. Experience with A-level curriculum preferred.',
      image: 'https://images.unsplash.com/photo-1577896852664-39f1d44f76c5?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80'
    }
  ];

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-blue-500/20 to-purple-500/20 transform -skew-y-6"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-300">
              Find Your Perfect Teaching Role
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Browse through hundreds of teaching opportunities at top schools across the UK
            </p>
          </div>
        </div>
      </section>

      {/* Search Section */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="backdrop-blur-xl bg-white/10 rounded-2xl p-8 shadow-2xl">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type="text"
                  placeholder="Search by role or keyword"
                  className="w-full pl-12 pr-4 py-4 rounded-xl bg-white/5 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-white/30 transition-all duration-300"
                />
              </div>
              <div className="flex-1 relative">
                <MapPin className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <input
                  type="text"
                  placeholder="Location"
                  className="w-full pl-12 pr-4 py-4 rounded-xl bg-white/5 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-white/30 transition-all duration-300"
                />
              </div>
              <button className="px-8 py-4 bg-white text-black rounded-xl hover:bg-gray-100 transition-all duration-300 transform hover:scale-105">
                Search Jobs
              </button>
            </div>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters - Desktop */}
          <div className="hidden lg:block w-64">
            <div className="backdrop-blur-xl bg-white/10 rounded-2xl p-6 sticky top-8">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-lg font-semibold">Filters</h2>
                {Object.values(filters).some(arr => arr.length > 0) && (
                  <button 
                    onClick={clearFilters}
                    className="text-sm text-blue-400 hover:text-blue-300"
                  >
                    Clear all
                  </button>
                )}
              </div>
              
              <div className="space-y-6">
                <div>
                  <h3 className="font-medium mb-3">Job Type</h3>
                  <div className="space-y-2">
                    {['Full-time', 'Part-time', 'Temporary', 'Daily Supply'].map(type => (
                      <label key={type} className="flex items-center">
                        <input
                          type="checkbox"
                          checked={filters.jobType.includes(type)}
                          onChange={() => toggleFilter('jobType', type)}
                          className="rounded-md border-white/20 bg-white/5 text-blue-400 focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 focus:ring-offset-black"
                        />
                        <span className="ml-2 text-sm text-gray-300">{type}</span>
                      </label>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium mb-3">Subject</h3>
                  <div className="space-y-2">
                    {['Mathematics', 'English', 'Science', 'History', 'Geography', 'Art'].map(subject => (
                      <label key={subject} className="flex items-center">
                        <input
                          type="checkbox"
                          checked={filters.subject.includes(subject)}
                          onChange={() => toggleFilter('subject', subject)}
                          className="rounded-md border-white/20 bg-white/5 text-blue-400 focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 focus:ring-offset-black"
                        />
                        <span className="ml-2 text-sm text-gray-300">{subject}</span>
                      </label>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium mb-3">Experience</h3>
                  <div className="space-y-2">
                    {['Entry Level', '1-2 Years', '3-5 Years', '5+ Years'].map(exp => (
                      <label key={exp} className="flex items-center">
                        <input
                          type="checkbox"
                          checked={filters.experience.includes(exp)}
                          onChange={() => toggleFilter('experience', exp)}
                          className="rounded-md border-white/20 bg-white/5 text-blue-400 focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 focus:ring-offset-black"
                        />
                        <span className="ml-2 text-sm text-gray-300">{exp}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Mobile Filter Button */}
          <div className="lg:hidden">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="w-full py-3 px-4 flex items-center justify-center space-x-2 backdrop-blur-xl bg-white/10 rounded-xl border border-white/20 text-white"
            >
              <Filter className="h-5 w-5" />
              <span>Filters</span>
              {Object.values(filters).some(arr => arr.length > 0) && (
                <span className="ml-2 bg-blue-400 text-black text-xs rounded-full px-2 py-1">
                  {Object.values(filters).flat().length}
                </span>
              )}
            </button>
          </div>
          
          {/* Job Listings */}
          <div className="flex-1">
            <div className="grid gap-6">
              {jobs.map(job => (
                <div 
                  key={job.id} 
                  className="backdrop-blur-xl bg-white/10 rounded-2xl p-6 border border-white/10 hover:border-white/20 transition-all duration-300"
                >
                  <div className="flex flex-col md:flex-row gap-6">
                    <div className="md:w-1/3">
                      <img
                        src={job.image}
                        alt={job.school}
                        className="w-full h-48 object-cover rounded-xl"
                      />
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-xl font-semibold text-white">{job.title}</h3>
                          <p className="text-gray-400">{job.school}</p>
                        </div>
                        <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                          job.type === 'Full-time' ? 'bg-green-400/20 text-green-400' :
                          job.type === 'Part-time' ? 'bg-blue-400/20 text-blue-400' :
                          'bg-yellow-400/20 text-yellow-400'
                        }`}>
                          {job.type}
                        </span>
                      </div>
                      
                      <div className="mt-4 space-y-2">
                        <div className="flex items-center text-gray-400">
                          <MapPin className="h-4 w-4 mr-2" />
                          {job.location}
                        </div>
                        <div className="flex items-center text-gray-400">
                          <Clock className="h-4 w-4 mr-2" />
                          Posted {job.posted}
                        </div>
                        <div className="flex items-center text-gray-400">
                          <DollarSign className="h-4 w-4 mr-2" />
                          {job.salary}
                        </div>
                      </div>
                      
                      <p className="mt-4 text-gray-300">{job.description}</p>
                      
                      <div className="mt-6 flex items-center justify-between">
                        <Link 
                          to={`/jobs/${job.id}`}
                          className="text-blue-400 hover:text-blue-300 flex items-center"
                        >
                          View Details
                          <Briefcase className="ml-2 h-4 w-4" />
                        </Link>
                        <button className="px-6 py-2 bg-white text-black rounded-xl hover:bg-gray-100 transition-all duration-300 transform hover:scale-105">
                          Apply Now
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            {/* Pagination */}
            <div className="mt-12 flex justify-center">
              <nav className="flex items-center space-x-2">
                <button className="px-4 py-2 rounded-xl border border-white/20 text-gray-300 hover:bg-white/10">
                  Previous
                </button>
                <button className="px-4 py-2 rounded-xl bg-white text-black">1</button>
                <button className="px-4 py-2 rounded-xl border border-white/20 text-gray-300 hover:bg-white/10">2</button>
                <button className="px-4 py-2 rounded-xl border border-white/20 text-gray-300 hover:bg-white/10">3</button>
                <span className="px-2 text-gray-400">...</span>
                <button className="px-4 py-2 rounded-xl border border-white/20 text-gray-300 hover:bg-white/10">8</button>
                <button className="px-4 py-2 rounded-xl border border-white/20 text-gray-300 hover:bg-white/10">
                  Next
                </button>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobsPage;