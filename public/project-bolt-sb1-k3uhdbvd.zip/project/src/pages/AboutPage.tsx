import React from 'react';
import { GraduationCap, Users, Globe, Award, Heart, Star, Shield, BookOpen } from 'lucide-react';

const AboutPage = () => {
  return (
    <div className="bg-black text-white pt-20">
      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-blue-500/20 to-purple-500/20 transform -skew-y-6"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex items-center justify-center mb-6">
              <GraduationCap className="h-12 w-12 text-blue-400" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-300">
              About GoTeach
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              We're on a mission to transform education staffing by connecting exceptional teachers with schools that need them most.
            </p>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 bg-gradient-to-b from-black to-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">Our Mission</h2>
              <p className="text-gray-300 mb-6 leading-relaxed">
                At GoTeach, we believe that every student deserves access to quality education, and every teacher deserves the opportunity to make a difference in students' lives.
              </p>
              <p className="text-gray-300 leading-relaxed">
                We're building a platform that makes it easier for schools to find qualified teachers, and for teachers to find positions where they can thrive and grow professionally.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-6">
              <div className="backdrop-blur-xl bg-white/5 rounded-2xl p-6 border border-white/10">
                <Users className="h-8 w-8 text-blue-400 mb-4" />
                <h3 className="text-lg font-semibold mb-2">Community</h3>
                <p className="text-gray-400">Building a strong network of educators and institutions</p>
              </div>
              <div className="backdrop-blur-xl bg-white/5 rounded-2xl p-6 border border-white/10">
                <Globe className="h-8 w-8 text-blue-400 mb-4" />
                <h3 className="text-lg font-semibold mb-2">Reach</h3>
                <p className="text-gray-400">Connecting teachers with opportunities nationwide</p>
              </div>
              <div className="backdrop-blur-xl bg-white/5 rounded-2xl p-6 border border-white/10">
                <Shield className="h-8 w-8 text-blue-400 mb-4" />
                <h3 className="text-lg font-semibold mb-2">Quality</h3>
                <p className="text-gray-400">Ensuring high standards in education staffing</p>
              </div>
              <div className="backdrop-blur-xl bg-white/5 rounded-2xl p-6 border border-white/10">
                <Heart className="h-8 w-8 text-blue-400 mb-4" />
                <h3 className="text-lg font-semibold mb-2">Support</h3>
                <p className="text-gray-400">Providing dedicated assistance every step of the way</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-gradient-to-b from-gray-900 to-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-6">Our Values</h2>
            <p className="text-gray-300 max-w-3xl mx-auto">
              These core values guide everything we do at GoTeach
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="backdrop-blur-xl bg-white/5 rounded-2xl p-8 border border-white/10">
              <Star className="h-10 w-10 text-yellow-400 mb-6" />
              <h3 className="text-xl font-semibold mb-4">Excellence</h3>
              <p className="text-gray-400">
                We maintain high standards in everything we do, from teacher verification to school partnerships.
              </p>
            </div>
            
            <div className="backdrop-blur-xl bg-white/5 rounded-2xl p-8 border border-white/10">
              <Award className="h-10 w-10 text-blue-400 mb-6" />
              <h3 className="text-xl font-semibold mb-4">Innovation</h3>
              <p className="text-gray-400">
                We continuously improve our platform to make education staffing more efficient and effective.
              </p>
            </div>
            
            <div className="backdrop-blur-xl bg-white/5 rounded-2xl p-8 border border-white/10">
              <BookOpen className="h-10 w-10 text-green-400 mb-6" />
              <h3 className="text-xl font-semibold mb-4">Education</h3>
              <p className="text-gray-400">
                We believe in the power of education to transform lives and communities.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-gradient-to-b from-black to-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-6">Our Team</h2>
            <p className="text-gray-300 max-w-3xl mx-auto">
              Meet the passionate individuals behind GoTeach
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="backdrop-blur-xl bg-white/5 rounded-2xl p-8 border border-white/10 text-center">
              <img
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=300&h=300&q=80"
                alt="Team member"
                className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
              />
              <h3 className="text-xl font-semibold mb-2">John Smith</h3>
              <p className="text-gray-400 mb-4">CEO & Founder</p>
              <p className="text-gray-300 text-sm">
                Former teacher with 15 years of experience in education
              </p>
            </div>
            
            <div className="backdrop-blur-xl bg-white/5 rounded-2xl p-8 border border-white/10 text-center">
              <img
                src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=300&h=300&q=80"
                alt="Team member"
                className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
              />
              <h3 className="text-xl font-semibold mb-2">Sarah Johnson</h3>
              <p className="text-gray-400 mb-4">Head of Operations</p>
              <p className="text-gray-300 text-sm">
                Specializes in educational technology and school partnerships
              </p>
            </div>
            
            <div className="backdrop-blur-xl bg-white/5 rounded-2xl p-8 border border-white/10 text-center">
              <img
                src="https://images.unsplash.com/photo-1519345182560-3f2917c472ef?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=300&h=300&q=80"
                alt="Team member"
                className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
              />
              <h3 className="text-xl font-semibold mb-2">Michael Brown</h3>
              <p className="text-gray-400 mb-4">Technical Director</p>
              <p className="text-gray-300 text-sm">
                Expert in creating seamless educational platforms
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;