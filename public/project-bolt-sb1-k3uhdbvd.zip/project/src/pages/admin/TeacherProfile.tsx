import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  ArrowLeft, 
  FileCheck, 
  FileClock, 
  FileX, 
  CheckCircle, 
  XCircle, 
  Clock, 
  DollarSign, 
  Briefcase, 
  MapPin, 
  Calendar, 
  User, 
  Phone, 
  Mail, 
  FileText, 
  Award, 
  BookOpen
} from 'lucide-react';

const TeacherProfile = () => {
  const { id } = useParams();
  const [activeTab, setActiveTab] = useState('overview');
  
  // Mock teacher data
  const teacher = {
    id: parseInt(id || '1'),
    name: 'Sarah Johnson',
    email: 'sarah.johnson@example.com',
    phone: '+44 7123 456789',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
    subject: 'Mathematics',
    experience: '5 years',
    qualifications: 'PGCE, BSc Mathematics',
    joined: '2023-05-15',
    status: 'verified', // verified, pending, suspended, rejected
    bio: 'Experienced mathematics teacher with a passion for making complex concepts accessible to all students. Specialized in teaching KS3 and KS4 mathematics with a focus on GCSE preparation.',
    documents: [
      { id: 1, name: 'Proof of Identity', type: 'passport', status: 'verified', uploadDate: '2023-05-16', verifiedDate: '2023-05-18', notes: 'Valid passport verified' },
      { id: 2, name: 'Enhanced DBS Check', type: 'certificate', status: 'verified', uploadDate: '2023-05-16', verifiedDate: '2023-05-20', notes: 'DBS check clear, no issues found' },
      { id: 3, name: 'National Insurance Number', type: 'document', status: 'verified', uploadDate: '2023-05-16', verifiedDate: '2023-05-18', notes: 'NI number verified' },
      { id: 4, name: 'CV with References', type: 'document', status: 'pending', uploadDate: '2023-05-16', verifiedDate: null, notes: 'Waiting for reference check' },
    ],
    jobs: [
      { 
        id: 1, 
        title: 'Mathematics Teacher - Year 10', 
        school: 'Oakridge Secondary School',
        location: 'London, UK',
        startDate: '2023-06-10',
        endDate: '2023-07-15',
        status: 'completed',
        paymentStatus: 'paid',
        amount: '£3,600',
        feedback: 'Excellent teacher, students responded very well to her teaching methods.'
      },
      { 
        id: 2, 
        title: 'Mathematics Teacher - Year 11 GCSE', 
        school: 'St. Mary\'s Academy',
        location: 'Manchester, UK',
        startDate: '2023-08-01',
        endDate: '2023-09-15',
        status: 'completed',
        paymentStatus: 'pending',
        amount: '£4,200',
        feedback: 'Good classroom management and subject knowledge.'
      },
      { 
        id: 3, 
        title: 'Mathematics Teacher - Year 9', 
        school: 'Westfield Comprehensive',
        location: 'Birmingham, UK',
        startDate: '2023-10-01',
        endDate: '2023-12-15',
        status: 'active',
        paymentStatus: 'unpaid',
        amount: '£6,300',
        feedback: null
      },
    ],
    applications: [
      { 
        id: 1, 
        jobTitle: 'Mathematics Teacher - Year 10', 
        school: 'Oakridge Secondary School',
        appliedDate: '2023-06-01',
        status: 'accepted',
        notes: 'Hired for the position'
      },
      { 
        id: 2, 
        jobTitle: 'Mathematics Teacher - Year 11 GCSE', 
        school: 'St. Mary\'s Academy',
        appliedDate: '2023-07-15',
        status: 'accepted',
        notes: 'Hired for the position'
      },
      { 
        id: 3, 
        jobTitle: 'Mathematics Teacher - Year 9', 
        school: 'Westfield Comprehensive',
        appliedDate: '2023-09-20',
        status: 'accepted',
        notes: 'Hired for the position'
      },
      { 
        id: 4, 
        jobTitle: 'Mathematics Teacher - A Level', 
        school: 'Greenwood High School',
        appliedDate: '2023-10-05',
        status: 'rejected',
        notes: 'Position filled by another candidate'
      },
      { 
        id: 5, 
        jobTitle: 'Mathematics Teacher - Year 8', 
        school: 'Riverside Academy',
        appliedDate: '2023-11-10',
        status: 'pending',
        notes: 'Application under review'
      },
    ],
    stats: {
      totalJobs: 3,
      totalEarnings: '£14,100',
      averageRating: 4.5,
      completionRate: '100%',
      applicationSuccessRate: '60%'
    }
  };
  
  const getStatusBadgeClass = (status) => {
    switch (status) {
      case 'verified':
      case 'completed':
      case 'accepted':
      case 'paid':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'rejected':
      case 'suspended':
        return 'bg-red-100 text-red-800';
      case 'active':
        return 'bg-blue-100 text-blue-800';
      case 'unpaid':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  const handleVerifyDocument = (documentId) => {
    console.log(`Verifying document ${documentId}`);
    // In a real app, this would call an API to update the document's status
  };
  
  const handleRejectDocument = (documentId) => {
    console.log(`Rejecting document ${documentId}`);
    // In a real app, this would call an API to update the document's status
  };
  
  const handleUpdatePaymentStatus = (jobId, status) => {
    console.log(`Updating payment status for job ${jobId} to ${status}`);
    // In a real app, this would call an API to update the job's payment status
  };
  
  const handleUpdateTeacherStatus = (status) => {
    console.log(`Updating teacher status to ${status}`);
    // In a real app, this would call an API to update the teacher's status
  };
  
  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };

  return (
    <div>
      <div className="mb-6">
        <Link to="/admin/teachers" className="inline-flex items-center text-blue-600 hover:text-blue-800">
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to Teachers
        </Link>
      </div>
      
      {/* Teacher Profile Header */}
      <div className="bg-white shadow rounded-lg overflow-hidden mb-6">
        <div className="p-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div className="flex items-center">
              <img 
                src={teacher.avatar} 
                alt={teacher.name} 
                className="h-16 w-16 rounded-full object-cover"
              />
              <div className="ml-4">
                <h2 className="text-2xl font-bold text-gray-900">{teacher.name}</h2>
                <div className="flex items-center mt-1">
                  <BookOpen className="h-4 w-4 text-gray-500 mr-1" />
                  <span className="text-gray-600">{teacher.subject} Teacher</span>
                  <span className="mx-2 text-gray-300">•</span>
                  <span className="text-gray-600">{teacher.experience} Experience</span>
                </div>
                <div className="mt-2">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusBadgeClass(teacher.status)}`}>
                    {teacher.status.charAt(0).toUpperCase() + teacher.status.slice(1)}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="mt-4 md:mt-0 flex flex-wrap gap-2">
              {teacher.status === 'pending' && (
                <>
                  <button
                    onClick={() => handleUpdateTeacherStatus('verified')}
                    className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                  >
                    <CheckCircle className="h-4 w-4 mr-1" />
                    Verify Account
                  </button>
                  <button
                    onClick={() => handleUpdateTeacherStatus('rejected')}
                    className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                  >
                    <XCircle className="h-4 w-4 mr-1" />
                    Reject
                  </button>
                </>
              )}
              {teacher.status === 'verified' && (
                <button
                  onClick={() => handleUpdateTeacherStatus('suspended')}
                  className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-orange-600 hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500"
                >
                  <XCircle className="h-4 w-4 mr-1" />
                  Suspend Account
                </button>
              )}
              {teacher.status === 'suspended' && (
                <button
                  onClick={() => handleUpdateTeacherStatus('verified')}
                  className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                >
                  <CheckCircle className="h-4 w-4 mr-1" />
                  Reactivate Account
                </button>
              )}
              {teacher.status === 'rejected' && (
                <button
                  onClick={() => handleUpdateTeacherStatus('verified')}
                  className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                >
                  <CheckCircle className="h-4 w-4 mr-1" />
                  Approve Account
                </button>
              )}
            </div>
          </div>
          
          <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-gray-50 p-3 rounded-md">
              <div className="text-sm font-medium text-gray-500">Total Jobs</div>
              <div className="mt-1 text-xl font-semibold text-gray-900">{teacher.stats.totalJobs}</div>
            </div>
            <div className="bg-gray-50 p-3 rounded-md">
              <div className="text-sm font-medium text-gray-500">Total Earnings</div>
              <div className="mt-1 text-xl font-semibold text-gray-900">{teacher.stats.totalEarnings}</div>
            </div>
            <div className="bg-gray-50 p-3 rounded-md">
              <div className="text-sm font-medium text-gray-500">Completion Rate</div>
              <div className="mt-1 text-xl font-semibold text-gray-900">{teacher.stats.completionRate}</div>
            </div>
            <div className="bg-gray-50 p-3 rounded-md">
              <div className="text-sm font-medium text-gray-500">Application Success</div>
              <div className="mt-1 text-xl font-semibold text-gray-900">{teacher.stats.applicationSuccessRate}</div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Tabs */}
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="border-b border-gray-200">
          <nav className="flex -mb-px">
            <button
              onClick={() => setActiveTab('overview')}
              className={`py-4 px-6 text-sm font-medium ${
                activeTab === 'overview'
                  ? 'border-b-2 border-blue-500 text-blue-600'
                  : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => setActiveTab('jobs')}
              className={`py-4 px-6 text-sm font-medium ${
                activeTab === 'jobs'
                  ? 'border-b-2 border-blue-500 text-blue-600'
                  : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Jobs & Payments
            </button>
            <button
              onClick={() => setActiveTab('applications')}
              className={`py-4 px-6 text-sm font-medium ${
                activeTab === 'applications'
                  ? 'border-b-2 border-blue-500 text-blue-600'
                  : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Applications
            </button>
            <button
              onClick={() => setActiveTab('documents')}
              className={`py-4 px-6 text-sm font-medium ${
                activeTab === 'documents'
                  ? 'border-b-2 border-blue-500 text-blue-600'
                  : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Documents
            </button>
          </nav>
        </div>
        
        <div className="p-6">
          {/* Overview Tab */}
          {activeTab === 'overview' && (
            <div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-2">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Teacher Information</h3>
                  <div className="bg-gray-50 rounded-md p-4">
                    <p className="text-gray-700 mb-4">{teacher.bio}</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                      <div className="flex items-start">
                        <User className="h-5 w-5 text-gray-400 mt-0.5 mr-2" />
                        <div>
                          <p className="text-sm font-medium text-gray-500">Full Name</p>
                          <p className="text-sm text-gray-900">{teacher.name}</p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <Mail className="h-5 w-5 text-gray-400 mt-0.5 mr-2" />
                        <div>
                          <p className="text-sm font-medium text-gray-500">Email</p>
                          <p className="text-sm text-gray-900">{teacher.email}</p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <Phone className="h-5 w-5 text-gray-400 mt-0.5 mr-2" />
                        <div>
                          <p className="text-sm font-medium text-gray-500">Phone</p>
                          <p className="text-sm text-gray-900">{teacher.phone}</p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <BookOpen className="h-5 w-5 text-gray-400 mt-0.5 mr-2" />
                        <div>
                          <p className="text-sm font-medium text-gray-500">Subject</p>
                          <p className="text-sm text-gray-900">{teacher.subject}</p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <Award className="h-5 w-5 text-gray-400 mt-0.5 mr-2" />
                        <div>
                          <p className="text-sm font-medium text-gray-500">Qualifications</p>
                          <p className="text-sm text-gray-900">{teacher.qualifications}</p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <Calendar className="h-5 w-5 text-gray-400 mt-0.5 mr-2" />
                        <div>
                          <p className="text-sm font-medium text-gray-500">Joined</p>
                          <p className="text-sm text-gray-900">{formatDate(teacher.joined)}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium text-gray-900 mb-4">Document Status</h3>
                  <div className="bg-gray-50 rounded-md p-4">
                    <ul className="space-y-3">
                      {teacher.documents.map(doc => (
                        <li key={doc.id} className="flex items-center justify-between">
                          <div className="flex items-center">
                            <FileText className="h-5 w-5 text-gray-400 mr-2" />
                            <span className="text-sm text-gray-900">{doc.name}</span>
                          </div>
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusBadgeClass(doc.status)}`}>
                            {doc.status.charAt(0).toUpperCase() + doc.status.slice(1)}
                          </span>
                        </li>
                      ))}
                    </ul>
                    
                    <div className="mt-4 pt-4 border-t border-gray-200">
                      <h4 className="text-sm font-medium text-gray-900 mb-2">Account Status</h4>
                      <div className="flex items-center">
                        {teacher.status === 'verified' ? (
                          <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                        ) : teacher.status === 'pending' ? (
                          <Clock className="h-5 w-5 text-yellow-500 mr-2" />
                        ) : (
                          <XCircle className="h-5 w-5 text-red-500 mr-2" />
                        )}
                        <span className={`text-sm font-medium ${
                          teacher.status === 'verified' ? 'text-green-700' : 
                          teacher.status === 'pending' ? 'text-yellow-700' : 'text-red-700'
                        }`}>
                          {teacher.status === 'verified' ? 'Account Verified' : 
                           teacher.status === 'pending' ? 'Verification Pending' : 
                           teacher.status === 'suspended' ? 'Account Suspended' : 'Account Rejected'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mt-8">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Recent Jobs</h3>
                <div className="bg-white shadow overflow-hidden sm:rounded-md">
                  <ul className="divide-y divide-gray-200">
                    {teacher.jobs.slice(0, 3).map(job => (
                      <li key={job.id}>
                        <div className="px-4 py-4 sm:px-6">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <div className="flex-shrink-0">
                                <Briefcase className="h-6 w-6 text-gray-400" />
                              </div>
                              <div className="ml-4">
                                <p className="text-sm font-medium text-blue-600">{job.title}</p>
                                <p className="text-sm text-gray-500">{job.school}</p>
                              </div>
                            </div>
                            <div className="ml-2 flex-shrink-0 flex">
                              <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeClass(job.status)}`}>
                                {job.status.charAt(0).toUpperCase() + job.status.slice(1)}
                              </span>
                            </div>
                          </div>
                          <div className="mt-2 sm:flex sm:justify-between">
                            <div className="sm:flex">
                              <div className="flex items-center text-sm text-gray-500">
                                <MapPin className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                                {job.location}
                              </div>
                              <div className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0 sm:ml-6">
                                <Calendar className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                                {formatDate(job.startDate)} - {formatDate(job.endDate)}
                              </div>
                            </div>
                            <div className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0">
                              <DollarSign className="flex-shrink-0 mr-1.5 h-4 w-4 text-gray-400" />
                              <span className={`font-medium ${
                                job.paymentStatus === 'paid' ? 'text-green-600' : 
                                job.paymentStatus === 'pending' ? 'text-yellow-600' : 'text-red-600'
                              }`}>
                                {job.paymentStatus.charAt(0).toUpperCase() + job.paymentStatus.slice(1)}
                              </span>
                            </div>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}
          
          {/* Jobs & Payments Tab */}
          {activeTab === 'jobs' && (
            <div>
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">Jobs & Payment History</h3>
                <button className="text-sm text-blue-600 hover:text-blue-800">
                  Export Payment History
                </button>
              </div>
              
              <div className="bg-white shadow overflow-hidden border border-gray-200 sm:rounded-lg">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Job Details
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Period
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Payment
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Amount
                      </th>
                      <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {teacher.jobs.map(job => (
                      <tr key={job.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">{job.title}</div>
                          <div className="text-sm text-gray-500">{job.school}</div>
                          <div className="text-xs text-gray-500 flex items-center mt-1">
                            <MapPin className="h-3 w-3 text-gray-400 mr-1" />
                            {job.location}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{formatDate(job.startDate)}</div>
                          <div className="text-sm text-gray-500">to {formatDate(job.endDate)}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeClass(job.status)}`}>
                            {job.status.charAt(0).toUpperCase() + job.status.slice(1)}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeClass(job.paymentStatus)}`}>
                            {job.paymentStatus.charAt(0).toUpperCase() + job.paymentStatus.slice(1)}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {job.amount}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          {job.paymentStatus === 'unpaid' && (
                            <button
                              onClick={() => handleUpdatePaymentStatus(job.id, 'paid')}
                              className="text-green-600 hover:text-green-900 mr-3"
                            >
                              Mark as Paid
                            </button>
                          )}
                          {job.paymentStatus === 'pending' && (
                            <>
                              <button
                                onClick={() => handleUpdatePaymentStatus(job.id, 'paid')}
                                className="text-green-600 hover:text-green-900 mr-3"
                              >
                                Mark as Paid
                              </button>
                              <button
                                onClick={() => handleUpdatePaymentStatus(job.id, 'unpaid')}
                                className="text-red-600 hover:text-red-900"
                              >
                                Mark as Unpaid
                              </button>
                            </>
                          )}
                          {job.paymentStatus === 'paid' && (
                            <button
                              onClick={() => handleUpdatePaymentStatus(job.id, 'pending')}
                              className="text-yellow-600 hover:text-yellow-900"
                            >
                              Mark as Pending
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              {teacher.jobs.length > 0 && (
                <div className="mt-6 bg-gray-50 p-4 rounded-md">
                  <h4 className="text-sm font-medium text-gray-900 mb-2">Payment Summary</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">Total Earnings</p>
                      <p className="text-lg font-medium text-gray-900">{teacher.stats.totalEarnings}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Paid</p>
                      <p className="text-lg font-medium text-green-600">
                        {teacher.jobs.filter(job => job.paymentStatus === 'paid').reduce((sum, job) => {
                          const amount = parseFloat(job.amount.replace('£', '').replace(',', ''));
                          return sum + amount;
                        }, 0).toLocaleString('en-GB', { style: 'currency', currency: 'GBP' })}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Pending/Unpaid</p>
                      <p className="text-lg font-medium text-red-600">
                        {teacher.jobs.filter(job => job.paymentStatus !== 'paid').reduce((sum, job) => {
                          const amount = parseFloat(job.amount.replace('£', '').replace(',', ''));
                          return sum + amount;
                        }, 0).toLocaleString('en-GB', { style: 'currency', currency: 'GBP' })}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
          
          {/* Applications Tab */}
          {activeTab === 'applications' && (
            <div>
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">Job Applications</h3>
                <div className="flex items-center space-x-2">
                  <select className="text-sm border-gray-300 rounded-md shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                    <option value="all">All Applications</option>
                    <option value="accepted">Accepted</option>
                    <option value="pending">Pending</option>
                    <option value="rejected">Rejected</option>
                  </select>
                </div>
              </div>
              
              <div className="bg-white shadow overflow-hidden border border-gray-200 sm:rounded-lg">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Job
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        School
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Applied Date
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Notes
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {teacher.applications.map(application => (
                      <tr key={application.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">{application.jobTitle}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{application.school}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{formatDate(application.appliedDate)}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeClass(application.status)}`}>
                            {application.status.charAt(0).toUpperCase() + application.status.slice(1)}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {application.notes}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              <div className="mt-6 bg-gray-50 p-4 rounded-md">
                <h4 className="text-sm font-medium text-gray-900 mb-2">Application Statistics</h4>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Total Applications</p>
                    <p className="text-lg font-medium text-gray-900">{teacher.applications.length}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Accepted</p>
                    <p className="text-lg font-medium text-green-600">
                      {teacher.applications.filter(app => app.status === 'accepted').length}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Pending</p>
                    <p className="text-lg font-medium text-yellow-600">
                      {teacher.applications.filter(app => app.status === 'pending').length}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Rejected</p>
                    <p className="text-lg font-medium text-red-600">
                      {teacher.applications.filter(app => app.status === 'rejected').length}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Documents Tab */}
          {activeTab === 'documents' && (
            <div>
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">Verification Documents</h3>
                <button className="text-sm text-blue-600 hover:text-blue-800">
                  Request Additional Documents
                </button>
              </div>
              
              <div className="bg-white shadow overflow-hidden border border-gray-200 sm:rounded-lg">
                <ul className="divide-y divide-gray-200">
                  {teacher.documents.map(doc => (
                    <li key={doc.id} className="p-4">
                      <div className="flex justify-between items-start">
                        <div className="flex items-start">
                          {doc.status === 'verified' ? (
                            <FileCheck className="h-8 w-8 text-green-500 mr-3" />
                          ) : doc.status === 'pending' ? (
                            <FileClock className="h-8 w-8 text-yellow-500 mr-3" />
                          ) : (
                            <FileX className="h-8 w-8 text-red-500 mr-3" />
                          )}
                          <div>
                            <h4 className="text-base font-medium text-gray-900">{doc.name}</h4>
                            <p className="text-sm text-gray-500">Type: {doc.type.charAt(0).toUpperCase() + doc.type.slice(1)}</p>
                            <div className="mt-1 flex items-center text-xs text-gray-500">
                              <span>Uploaded: {formatDate(doc.uploadDate)}</span>
                              {doc.verifiedDate && (
                                <>
                                  <span className="mx-2">•</span>
                                  <span>Verified: {formatDate(doc.verifiedDate)}</span>
                                </>
                              )}
                            </div>
                            {doc.notes && (
                              <p className="mt-2 text-sm text-gray-600">
                                <span className="font-medium">Notes:</span> {doc.notes}
                              </p>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeClass(doc.status)}`}>
                            {doc.status.charAt(0).toUpperCase() + doc.status.slice(1)}
                          </span>
                          
                          <div className="flex space-x-2 ml-4">
                            <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                              View
                            </button>
                            
                            {doc.status === 'pending' && (
                              <>
                                <button 
                                  onClick={() => handleVerifyDocument(doc.id)}
                                  className="text-green-600 hover:text-green-800 text-sm font-medium"
                                >
                                  Verify
                                </button>
                                <button 
                                  onClick={() => handleRejectDocument(doc.id)}
                                  className="text-red-600 hover:text-red-800 text-sm font-medium"
                                >
                                  Reject
                                </button>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
              
              <div className="mt-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Required Documents</h3>
                <div className="bg-white shadow overflow-hidden border border-gray-200 sm:rounded-lg">
                  <ul className="divide-y divide-gray-200">
                    <li className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <FileText className="h-5 w-5 text-gray-400 mr-2" />
                          <span className="text-sm font-medium text-gray-900">Proof of Identity</span>
                        </div>
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          teacher.documents.find(d => d.name === 'Proof of Identity')?.status === 'verified' 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {teacher.documents.find(d => d.name === 'Proof of Identity')?.status === 'verified' 
                            ? 'Verified' 
                            : 'Required'}
                        </span>
                      </div>
                    </li>
                    <li className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <FileText className="h-5 w-5 text-gray-400 mr-2" />
                          <span className="text-sm font-medium text-gray-900">Enhanced DBS Check</span>
                        </div>
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          teacher.documents.find(d => d.name === 'Enhanced DBS Check')?.status === 'verified' 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {teacher.documents.find(d => d.name === 'Enhanced DBS Check')?.status === 'verified' 
                            ? 'Verified' 
                            : 'Required'}
                        </span>
                      </div>
                    </li>
                    <li className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <FileText className="h-5 w-5 text-gray-400 mr-2" />
                          <span className="text-sm font-medium text-gray-900">National Insurance Number</span>
                        </div>
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          teacher.documents.find(d => d.name === 'National Insurance Number')?.status === 'verified' 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {teacher.documents.find(d => d.name === 'National Insurance Number')?.status === 'verified' 
                            ? 'Verified' 
                            : 'Required'}
                        </span>
                      </div>
                    </li>
                    <li className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <FileText className="h-5 w-5 text-gray-400 mr-2" />
                          <span className="text-sm font-medium text-gray-900">CV with References</span>
                        </div>
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          teacher.documents.find(d => d.name === 'CV with References')?.status === 'verified' 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {teacher.documents.find(d => d.name === 'CV with References')?.status === 'verified' 
                            ? 'Verified' 
                            : 'Required'}
                        </span>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TeacherProfile;