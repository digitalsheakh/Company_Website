import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Eye, EyeOff, GraduationCap, Building, ArrowRight, Shield, Users, Clock } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import AuthNav from '../components/AuthNav';

const RegisterPage = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [userType, setUserType] = useState('teacher');
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const { signUp } = useAuthStore();
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    firstName: '',
    lastName: '',
    phone: '',
    qualifications: '',
    subjects: [] as string[],
    experience: '',
    schoolName: '',
    position: '',
    schoolType: '',
    location: '',
  });
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubjectChange = (subject: string) => {
    setFormData(prev => {
      const subjects = [...prev.subjects];
      if (subjects.includes(subject)) {
        return { ...prev, subjects: subjects.filter(s => s !== subject) };
      } else {
        return { ...prev, subjects: [...subjects, subject] };
      }
    });
  };
  
  const validateForm = () => {
    if (step === 1) {
      if (!formData.email || !formData.password || !formData.confirmPassword) {
        setError('All fields are required');
        return false;
      }
      if (formData.password !== formData.confirmPassword) {
        setError('Passwords do not match');
        return false;
      }
      if (formData.password.length < 6) {
        setError('Password must be at least 6 characters');
        return false;
      }
    }

    if (step === 2 && userType === 'teacher') {
      if (!formData.firstName || !formData.lastName || !formData.phone || !formData.experience) {
        setError('All fields are required');
        return false;
      }
    }

    if (step === 3 && userType === 'teacher') {
      if (!formData.qualifications || formData.subjects.length === 0) {
        setError('All fields are required');
        return false;
      }
    }

    if (step === 2 && userType === 'school') {
      if (!formData.schoolName || !formData.position || !formData.schoolType || !formData.location) {
        setError('All fields are required');
        return false;
      }
    }

    return true;
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!validateForm()) {
      return;
    }

    if (step < (userType === 'teacher' ? 3 : 2)) {
      setStep(step + 1);
      return;
    }

    setLoading(true);

    try {
      const userData = userType === 'teacher' 
        ? {
            first_name: formData.firstName,
            last_name: formData.lastName,
            phone: formData.phone,
            qualifications: formData.qualifications,
            subjects: formData.subjects,
            experience: formData.experience,
          }
        : {
            name: formData.schoolName,
            position: formData.position,
            type: formData.schoolType,
            location: formData.location,
          };

      await signUp(formData.email, formData.password, userType, userData);
      navigate('/login', { state: { message: 'Registration successful! Please sign in.' } });
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };
  
  const goBack = () => {
    setError(null);
    setStep(step - 1);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <AuthNav />
      
      {/* Background Animation */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 via-purple-500/20 to-pink-500/20 animate-gradient"></div>
        <div className="absolute inset-0 backdrop-blur-3xl"></div>
      </div>

      <div className="relative z-10 flex min-h-screen">
        {/* Left Side - Form */}
        <div className="flex-1 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
          <div className="mx-auto w-full max-w-md">
            <div className="flex justify-center mb-8">
              <GraduationCap className="h-12 w-12 text-blue-400" />
            </div>
            
            <h2 className="text-center text-3xl font-extrabold bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-300 mb-8">
              Join GoTeach
            </h2>

            {error && (
              <div className="mb-4 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 flex items-center">
                <Eye className="h-5 w-5 mr-2" />
                <span className="text-sm">{error}</span>
              </div>
            )}

            {step === 1 && (
              <>
                <div className="mb-6">
                  <div className="flex border border-white/20 rounded-xl overflow-hidden">
                    <button
                      type="button"
                      className={`w-1/2 py-3 text-sm font-medium transition-all duration-200 flex items-center justify-center ${
                        userType === 'teacher'
                          ? 'bg-white text-black'
                          : 'bg-transparent text-white hover:bg-white/10'
                      }`}
                      onClick={() => setUserType('teacher')}
                    >
                      <GraduationCap className="h-4 w-4 mr-2" />
                      Teacher
                    </button>
                    <button
                      type="button"
                      className={`w-1/2 py-3 text-sm font-medium transition-all duration-200 flex items-center justify-center ${
                        userType === 'school'
                          ? 'bg-white text-black'
                          : 'bg-transparent text-white hover:bg-white/10'
                      }`}
                      onClick={() => setUserType('school')}
                    >
                      <Building className="h-4 w-4 mr-2" />
                      School
                    </button>
                  </div>
                </div>
                
                <form className="space-y-6" onSubmit={handleSubmit}>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-300">
                      Email address
                    </label>
                    <div className="mt-1">
                      <input
                        id="email"
                        name="email"
                        type="email"
                        autoComplete="email"
                        required
                        value={formData.email}
                        onChange={handleChange}
                        className="appearance-none block w-full px-4 py-3 rounded-xl bg-white/5 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all duration-200"
                        placeholder="Enter your email"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="password" className="block text-sm font-medium text-gray-300">
                      Password
                    </label>
                    <div className="mt-1 relative">
                      <input
                        id="password"
                        name="password"
                        type={showPassword ? 'text' : 'password'}
                        autoComplete="new-password"
                        required
                        value={formData.password}
                        onChange={handleChange}
                        className="appearance-none block w-full px-4 py-3 rounded-xl bg-white/5 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all duration-200"
                        placeholder="Create a password"
                      />
                      <button
                        type="button"
                        className="absolute inset-y-0 right-0 pr-3 flex items-center"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? (
                          <EyeOff className="h-5 w-5 text-gray-400" />
                        ) : (
                          <Eye className="h-5 w-5 text-gray-400" />
                        )}
                      </button>
                    </div>
                  </div>

                  <div>
                    <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-300">
                      Confirm Password
                    </label>
                    <div className="mt-1">
                      <input
                        id="confirmPassword"
                        name="confirmPassword"
                        type={showPassword ? 'text' : 'password'}
                        autoComplete="new-password"
                        required
                        value={formData.confirmPassword}
                        onChange={handleChange}
                        className="appearance-none block w-full px-4 py-3 rounded-xl bg-white/5 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all duration-200"
                        placeholder="Confirm your password"
                      />
                    </div>
                  </div>

                  <div>
                    <button
                      type="submit"
                      className="w-full flex justify-center items-center py-3 px-4 border border-transparent rounded-xl shadow-sm text-sm font-medium text-black bg-white hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-400 transform transition-all duration-200 hover:scale-105"
                    >
                      Continue
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </button>
                  </div>
                </form>
              </>
            )}
            
            {step === 2 && userType === 'teacher' && (
              <form className="space-y-6" onSubmit={handleSubmit}>
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-medium">Personal Information</h3>
                  <div className="text-sm text-gray-400">Step 2 of 3</div>
                </div>
                
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                  <div>
                    <label htmlFor="firstName" className="block text-sm font-medium text-gray-300">
                      First Name
                    </label>
                    <div className="mt-1">
                      <input
                        id="firstName"
                        name="firstName"
                        type="text"
                        required
                        value={formData.firstName}
                        onChange={handleChange}
                        className="appearance-none block w-full px-4 py-3 rounded-xl bg-white/5 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all duration-200"
                        placeholder="Enter first name"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label htmlFor="lastName" className="block text-sm font-medium text-gray-300">
                      Last Name
                    </label>
                    <div className="mt-1">
                      <input
                        id="lastName"
                        name="lastName"
                        type="text"
                        required
                        value={formData.lastName}
                        onChange={handleChange}
                        className="appearance-none block w-full px-4 py-3 rounded-xl bg-white/5 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all duration-200"
                        placeholder="Enter last name"
                      />
                    </div>
                  </div>
                </div>
                
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-300">
                    Phone Number
                  </label>
                  <div className="mt-1">
                    <input
                      id="phone"
                      name="phone"
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={handleChange}
                      className="appearance-none block w-full px-4 py-3 rounded-xl bg-white/5 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all duration-200"
                      placeholder="Enter phone number"
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="experience" className="block text-sm font-medium text-gray-300">
                    Years of Teaching Experience
                  </label>
                  <div className="mt-1">
                    <select
                      id="experience"
                      name="experience"
                      required
                      value={formData.experience}
                      onChange={handleChange}
                      className="appearance-none block w-full px-4 py-3 rounded-xl bg-white/5 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all duration-200"
                    >
                      <option value="">Select experience</option>
                      <option value="0-1">Less than 1 year</option>
                      <option value="1-2">1-2 years</option>
                      <option value="3-5">3-5 years</option>
                      <option value="5-10">5-10 years</option>
                      <option value="10+">10+ years</option>
                    </select>
                  </div>
                </div>
                
                <div className="flex justify-between pt-4">
                  <button
                    type="button"
                    onClick={goBack}
                    className="px-6 py-3 border border-white/20 rounded-xl text-sm font-medium text-white hover:bg-white/10 transition-all duration-200"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-3 bg-white text-black rounded-xl text-sm font-medium hover:bg-gray-100 transform transition-all duration-200 hover:scale-105"
                  >
                    Continue
                  </button>
                </div>
              </form>
            )}
            
            {step === 3 && userType === 'teacher' && (
              <form className="space-y-6" onSubmit={handleSubmit}>
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-medium">Professional Information</h3>
                  <div className="text-sm text-gray-400">Step 3 of 3</div>
                </div>
                
                <div>
                  <label htmlFor="qualifications" className="block text-sm font-medium text-gray-300">
                    Qualifications
                  </label>
                  <div className="mt-1">
                    <select
                      id="qualifications"
                      name="qualifications"
                      required
                      value={formData.qualifications}
                      onChange={handleChange}
                      className="appearance-none block w-full px-4 py-3 rounded-xl bg-white/5 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all duration-200"
                    >
                      <option value="">Select qualification</option>
                      <option value="PGCE">PGCE</option>
                      <option value="QTS">QTS</option>
                      <option value="BEd">Bachelor of Education (BEd)</option>
                      <option value="MEd">Master of Education (MEd)</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Subjects You Can Teach
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    {['Mathematics', 'English', 'Science', 'History', 'Geography', 'Art', 'Physical Education', 'Music'].map(subject => (
                      <label key={subject} className="flex items-center p-3 rounded-xl bg-white/5 border border-white/20 cursor-pointer hover:bg-white/10 transition-all duration-200">
                        <input
                          type="checkbox"
                          checked={formData.subjects.includes(subject)}
                          onChange={() => handleSubjectChange(subject)}
                          className="h-4 w-4 rounded-md border-white/20 bg-white/5 text-blue-400 focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 focus:ring-offset-black"
                        />
                        <span className="ml-2 text-sm text-gray-300">{subject}</span>
                      </label>
                    ))}
                  </div>
                </div>
                
                <div className="flex justify-between pt-4">
                  <button
                    type="button"
                    onClick={goBack}
                    className="px-6 py-3 border border-white/20 rounded-xl text-sm font-medium text-white hover:bg-white/10 transition-all duration-200"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    className="px-6 py-3 bg-white text-black rounded-xl text-sm font-medium hover:bg-gray-100 transform transition-all duration-200 hover:scale-105 disabled:opacity-50"
                  >
                    {loading ? 'Creating Account...' : 'Complete Registration'}
                  </button>
                </div>
              </form>
            )}
            
            {step === 2 && userType === 'school' && (
              <form className="space-y-6" onSubmit={handleSubmit}>
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-medium">School Information</h3>
                  <div className="text-sm text-gray-400">Step 2 of 2</div>
                </div>
                
                <div>
                  <label htmlFor="schoolName" className="block text-sm font-medium text-gray-300">
                    School Name
                  </label>
                  <div className="mt-1">
                    <input
                      id="schoolName"
                      name="schoolName"
                      type="text"
                      required
                      value={formData.schoolName}
                      onChange={handleChange}
                      className="appearance-none block w-full px-4 py-3 rounded-xl bg-white/5 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all duration-200"
                      placeholder="Enter school name"
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="position" className="block text-sm font-medium text-gray-300">
                    Your Position
                  </label>
                  <div className="mt-1">
                    <input
                      id="position"
                      name="position"
                      type="text"
                      required
                      value={formData.position}
                      onChange={handleChange}
                      className="appearance-none block w-full px-4 py-3 rounded-xl bg-white/5 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all duration-200"
                      placeholder="Enter your position"
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="schoolType" className="block text-sm font-medium text-gray-300">
                    School Type
                  </label>
                  <div className="mt-1">
                    <select
                      id="schoolType"
                      name="schoolType"
                      required
                      value={formData.schoolType}
                      onChange={handleChange}
                      className="appearance-none block w-full px-4 py-3 rounded-xl bg-white/5 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all duration-200"
                    >
                      <option value="">Select school type</option>
                      <option value="primary">Primary School</option>
                      <option value="secondary">Secondary School</option>
                      <option value="college">Sixth Form College</option>
                      <option value="special">Special School</option>
                      <option value="independent">Independent School</option>
                    </select>
                  </div>
                </div>
                
                <div>
                  <label htmlFor="location" className="block text-sm font-medium text-gray-300">
                    Location
                  </label>
                  <div className="mt-1">
                    <input
                      id="location"
                      name="location"
                      type="text"
                      required
                      placeholder="City, County"
                      value={formData.location}
                      onChange={handleChange}
                      className="appearance-none block w-full px-4 py-3 rounded-xl bg-white/5 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all duration-200"
                    />
                  </div>
                </div>
                
                <div className="flex justify-between pt-4">
                  <button
                    type="button"
                    onClick={goBack}
                    className="px-6 py-3 border border-white/20 rounded-xl text-sm font-medium text-white hover:bg-white/10 transition-all duration-200"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    className="px-6 py-3 bg-white text-black rounded-xl text-sm font-medium hover:bg-gray-100 transform transition-all duration-200 hover:scale-105 disabled:opacity-50"
                  >
                    {loading ? 'Creating Account...' : 'Complete Registration'}
                  </button>
                </div>
              </form>
            )}

            <p className="mt-6 text-center text-sm text-gray-400">
              Already have an account?{' '}
              <Link to="/login" className="font-medium text-blue-400 hover:text-blue-300">
                Sign in
              </Link>
            </p>
          </div>
        </div>

        {/* Right Side - Features */}
        <div className="hidden lg:flex flex-1 items-center justify-center bg-gradient-to-br from-blue-600/20 to-purple-600/20 backdrop-blur-2xl">
          <div className="max-w-md px-8">
            <h3 className="text-2xl font-bold mb-8">Why Choose GoTeach?</h3>
            
            <div className="space-y-6">
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-white/10 text-blue-400">
                    <Shield className="h-6 w-6" />
                  </div>
                </div>
                <div className="ml-4">
                  <h4 className="text-lg font-medium mb-1">Verified Platform</h4>
                  <p className="text-gray-400">All teachers and schools are thoroughly vetted to ensure quality.</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-white/10 text-blue-400">
                    <Users className="h-6 w-6" />
                  </div>
                </div>
                <div className="ml-4">
                  <h4 className="text-lg font-medium mb-1">Perfect Match</h4>
                  <p className="text-gray-400">Our matching system helps find the right opportunities for you.</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-white/10 text-blue-400">
                    <Clock className="h-6 w-6" />
                  </div>
                </div>
                <div className="ml-4">
                  <h4 className="text-lg font-medium mb-1">Quick Process</h4>
                  <p className="text-gray-400">Get started and find opportunities quickly and easily.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;