import React from 'react';
import { Link } from 'react-router-dom';
import { 
  GraduationCap, 
  Building, 
  ArrowRight, 
  Shield, 
  Users, 
  Clock, 
  CheckCircle,
  Star,
  Award,
  BookOpen,
  Briefcase,
  Heart
} from 'lucide-react';

const HomePage = () => {
  return (
    <div className="bg-black text-white">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <video
            autoPlay
            loop
            muted
            playsInline
            className="absolute inset-0 w-full h-full object-cover opacity-50"
          >
            <source src="https://cdn.coverr.co/videos/coverr-teacher-helping-students-5714/1080p.mp4" type="video/mp4" />
          </video>
          <div className="absolute inset-0 bg-gradient-to-b from-black/50 to-black"></div>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
          <div className="text-center max-w-3xl mx-auto">
            <div className="flex items-center justify-center mb-6">
              <GraduationCap className="h-12 w-12 text-blue-400" />
              <span className="ml-3 text-3xl font-bold">GoTeach</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-300">
              Transforming Education Staffing
            </h1>
            <p className="mt-6 text-xl md:text-2xl text-gray-300 leading-relaxed">
              The smart way to connect exceptional teachers with schools that need them. Join thousands making a difference in education.
            </p>
            
            <div className="mt-12 grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-lg mx-auto">
              <Link 
                to="/register"
                className="group relative overflow-hidden px-6 py-4 rounded-xl bg-white text-black hover:bg-gray-100 transition-all duration-300"
              >
                <div className="flex items-center justify-center">
                  <GraduationCap className="h-6 w-6 mr-2" />
                  <span className="font-medium">I'm a Teacher</span>
                </div>
              </Link>
              
              <Link 
                to="/register"
                className="group relative overflow-hidden px-6 py-4 rounded-xl bg-blue-600 text-white hover:bg-blue-700 transition-all duration-300"
              >
                <div className="flex items-center justify-center">
                  <Building className="h-6 w-6 mr-2" />
                  <span className="font-medium">I'm a School</span>
                </div>
              </Link>
            </div>
            
            <p className="mt-6 text-gray-400">
              Already have an account?{' '}
              <Link to="/login" className="text-blue-400 hover:text-blue-300">
                Sign in
              </Link>
            </p>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-gradient-to-b from-black to-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div className="backdrop-blur-xl bg-white/5 rounded-2xl p-6 border border-white/10">
              <div className="text-4xl font-bold text-blue-400 mb-2">5,000+</div>
              <div className="text-gray-400">Active Teachers</div>
            </div>
            <div className="backdrop-blur-xl bg-white/5 rounded-2xl p-6 border border-white/10">
              <div className="text-4xl font-bold text-blue-400 mb-2">1,000+</div>
              <div className="text-gray-400">Partner Schools</div>
            </div>
            <div className="backdrop-blur-xl bg-white/5 rounded-2xl p-6 border border-white/10">
              <div className="text-4xl font-bold text-blue-400 mb-2">98%</div>
              <div className="text-gray-400">Satisfaction Rate</div>
            </div>
            <div className="backdrop-blur-xl bg-white/5 rounded-2xl p-6 border border-white/10">
              <div className="text-4xl font-bold text-blue-400 mb-2">24/7</div>
              <div className="text-gray-400">Support</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-gradient-to-b from-gray-900 to-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">Why Choose GoTeach</h2>
            <p className="text-xl text-gray-400">The trusted platform for educational staffing</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="backdrop-blur-xl bg-white/5 rounded-2xl p-8 border border-white/10 hover:bg-white/10 transition-all duration-300 transform hover:scale-105">
              <div className="text-blue-400 mb-6">
                <Shield className="h-12 w-12" />
              </div>
              <h3 className="text-2xl font-semibold mb-4">Verified Teachers</h3>
              <p className="text-gray-400 leading-relaxed">
                All teachers undergo thorough verification of qualifications and experience.
              </p>
            </div>
            
            <div className="backdrop-blur-xl bg-white/5 rounded-2xl p-8 border border-white/10 hover:bg-white/10 transition-all duration-300 transform hover:scale-105">
              <div className="text-blue-400 mb-6">
                <Users className="h-12 w-12" />
              </div>
              <h3 className="text-2xl font-semibold mb-4">Perfect Match</h3>
              <p className="text-gray-400 leading-relaxed">
                Our matching system ensures schools find teachers that fit their requirements perfectly.
              </p>
            </div>
            
            <div className="backdrop-blur-xl bg-white/5 rounded-2xl p-8 border border-white/10 hover:bg-white/10 transition-all duration-300 transform hover:scale-105">
              <div className="text-blue-400 mb-6">
                <Clock className="h-12 w-12" />
              </div>
              <h3 className="text-2xl font-semibold mb-4">Quick Process</h3>
              <p className="text-gray-400 leading-relaxed">
                Streamlined hiring process gets teachers into classrooms faster.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-24 bg-gradient-to-b from-black to-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold mb-6">For Teachers</h2>
              <div className="space-y-4">
                <div className="flex items-start">
                  <CheckCircle className="h-6 w-6 text-blue-400 mt-1 mr-3" />
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Find Your Dream Role</h3>
                    <p className="text-gray-400">Access hundreds of teaching opportunities at top schools.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Star className="h-6 w-6 text-blue-400 mt-1 mr-3" />
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Competitive Pay</h3>
                    <p className="text-gray-400">Earn what you deserve with transparent salary ranges.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Award className="h-6 w-6 text-blue-400 mt-1 mr-3" />
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Professional Growth</h3>
                    <p className="text-gray-400">Develop your career with diverse teaching opportunities.</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div>
              <h2 className="text-4xl font-bold mb-6">For Schools</h2>
              <div className="space-y-4">
                <div className="flex items-start">
                  <Users className="h-6 w-6 text-blue-400 mt-1 mr-3" />
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Quality Teachers</h3>
                    <p className="text-gray-400">Access a pool of verified, experienced educators.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Briefcase className="h-6 w-6 text-blue-400 mt-1 mr-3" />
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Easy Management</h3>
                    <p className="text-gray-400">Streamlined tools for posting jobs and managing applications.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <BookOpen className="h-6 w-6 text-blue-400 mt-1 mr-3" />
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Subject Expertise</h3>
                    <p className="text-gray-400">Find specialists across all subjects and levels.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-24 bg-gradient-to-b from-gray-900 to-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-6">Success Stories</h2>
            <p className="text-xl text-gray-400">Hear from our community</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="backdrop-blur-xl bg-white/5 rounded-2xl p-8 border border-white/10">
              <div className="flex items-center mb-6">
                <Heart className="h-6 w-6 text-red-400" />
                <div className="ml-4">
                  <div className="font-medium">Sarah Johnson</div>
                  <div className="text-sm text-gray-400">Mathematics Teacher</div>
                </div>
              </div>
              <p className="text-gray-300">
                "GoTeach made it incredibly easy to find my ideal teaching position. The platform is intuitive and the support team is fantastic."
              </p>
            </div>
            
            <div className="backdrop-blur-xl bg-white/5 rounded-2xl p-8 border border-white/10">
              <div className="flex items-center mb-6">
                <Heart className="h-6 w-6 text-red-400" />
                <div className="ml-4">
                  <div className="font-medium">Oakridge School</div>
                  <div className="text-sm text-gray-400">Secondary School</div>
                </div>
              </div>
              <p className="text-gray-300">
                "We've found exceptional teachers through GoTeach. The verification process gives us confidence in every hire."
              </p>
            </div>
            
            <div className="backdrop-blur-xl bg-white/5 rounded-2xl p-8 border border-white/10">
              <div className="flex items-center mb-6">
                <Heart className="h-6 w-6 text-red-400" />
                <div className="ml-4">
                  <div className="font-medium">James Wilson</div>
                  <div className="text-sm text-gray-400">Science Teacher</div>
                </div>
              </div>
              <p className="text-gray-300">
                "The platform's matching system helped me find schools that perfectly aligned with my teaching philosophy."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-b from-black to-gray-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20 transform -skew-y-6"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">Ready to Transform Education?</h2>
          <p className="text-xl text-gray-300 mb-12 max-w-3xl mx-auto">
            Join our community of educators and schools making a difference in students' lives.
          </p>
          <Link 
            to="/register" 
            className="inline-flex items-center px-8 py-4 text-lg font-medium rounded-full bg-white text-black hover:bg-gray-100 transition-all duration-300 transform hover:scale-105"
          >
            Get Started Today
            <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;