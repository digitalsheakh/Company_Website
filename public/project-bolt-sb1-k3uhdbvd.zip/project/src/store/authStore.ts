import { create } from 'zustand';
import { supabase } from '../lib/supabase';
import type { User } from '@supabase/supabase-js';

interface AuthState {
  user: User | null;
  userType: 'teacher' | 'school' | 'admin' | null;
  loading: boolean;
  error: string | null;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, userType: string, userData: any) => Promise<void>;
  signOut: () => Promise<void>;
  checkUser: () => Promise<void>;
  adminSignIn: (email: string, password: string) => Promise<void>;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  userType: null,
  loading: true,
  error: null,

  signIn: async (email: string, password: string) => {
    try {
      set({ loading: true, error: null });
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;

      set({ 
        user: data.user, 
        userType: data.user?.user_metadata?.user_type || null,
        loading: false 
      });
    } catch (error: any) {
      set({ error: error.message, loading: false });
      throw error;
    }
  },

  adminSignIn: async (email: string, password: string) => {
    try {
      set({ loading: true, error: null });
      
      // Hard-coded admin credentials
      const ADMIN_EMAIL = 'admin@goteach.com';
      const ADMIN_PASSWORD = 'admin123';

      if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
        // Create a mock admin user
        const adminUser = {
          id: 'admin',
          email: ADMIN_EMAIL,
          user_metadata: {
            user_type: 'admin'
          }
        };

        // Set admin session
        localStorage.setItem('adminAuth', 'true');

        set({ 
          user: adminUser as User, 
          userType: 'admin',
          loading: false 
        });
      } else {
        throw new Error('Invalid admin credentials');
      }
    } catch (error: any) {
      set({ error: error.message, loading: false });
      throw error;
    }
  },

  signUp: async (email: string, password: string, userType: string, userData: any) => {
    try {
      set({ loading: true, error: null });

      // Create auth user first
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            user_type: userType,
          },
        },
      });

      if (authError) throw authError;

      if (!authData.user) {
        throw new Error('Registration failed');
      }

      // Insert profile data based on user type
      const table = userType === 'teacher' ? 'teachers' : 'schools';
      const profileData = {
        id: authData.user.id,
        email: email,
        ...userData,
        status: 'pending'
      };

      const { error: profileError } = await supabase
        .from(table)
        .insert([profileData]);

      if (profileError) {
        console.error('Error creating profile:', profileError);
        throw new Error('Failed to create user profile');
      }

      set({ 
        user: authData.user, 
        userType: userType as 'teacher' | 'school',
        loading: false 
      });
    } catch (error: any) {
      if (error.message === 'User already registered') {
        set({ error: 'An account with this email already exists', loading: false });
      } else {
        set({ error: error.message, loading: false });
      }
      throw error;
    }
  },

  signOut: async () => {
    try {
      set({ loading: true, error: null });
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      localStorage.removeItem('adminAuth');
      set({ user: null, userType: null, loading: false });
    } catch (error: any) {
      set({ error: error.message, loading: false });
      throw error;
    }
  },

  checkUser: async () => {
    try {
      set({ loading: true, error: null });
      
      // Check if admin is logged in
      const isAdmin = localStorage.getItem('adminAuth') === 'true';
      if (isAdmin) {
        const adminUser = {
          id: 'admin',
          email: 'admin@goteach.com',
          user_metadata: {
            user_type: 'admin'
          }
        };
        set({ 
          user: adminUser as User, 
          userType: 'admin',
          loading: false 
        });
        return;
      }

      // Check regular user
      const { data: { user } } = await supabase.auth.getUser();
      set({ 
        user, 
        userType: user?.user_metadata?.user_type || null,
        loading: false 
      });
    } catch (error: any) {
      set({ error: error.message, loading: false });
      throw error;
    }
  },
}));