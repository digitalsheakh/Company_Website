# GoTeach

A modern platform connecting teachers with schools, built with React, TypeScript, and Tailwind CSS.

## Features

- Teacher and School registration
- Job posting and application system
- Document verification
- Payment tracking
- Admin dashboard
- Responsive design

## Tech Stack

- React
- TypeScript
- Tailwind CSS
- Supabase
- Vite

## Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Deploy to GitHub Pages
npm run deploy
```

## License

MIT