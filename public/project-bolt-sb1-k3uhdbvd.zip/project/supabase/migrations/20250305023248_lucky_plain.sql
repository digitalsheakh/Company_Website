/*
  # Add Job Applications Table

  1. New Tables
    - `job_applications`
      - `id` (uuid, primary key)
      - `job_id` (uuid, references jobs)
      - `teacher_id` (uuid, references teachers)
      - `school_id` (uuid, references schools)
      - `status` (text, enum: pending, accepted, rejected)
      - `notes` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS
    - Add policies for teachers and schools
*/

-- Create job_applications table
CREATE TABLE IF NOT EXISTS job_applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid REFERENCES jobs(id) ON DELETE CASCADE,
  teacher_id uuid REFERENCES teachers(id) ON DELETE CASCADE,
  school_id uuid REFERENCES schools(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'pending',
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  
  CONSTRAINT valid_status CHECK (status IN ('pending', 'accepted', 'rejected'))
);

-- Enable RLS
ALTER TABLE job_applications ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Teachers can view own applications"
  ON job_applications
  FOR SELECT
  TO authenticated
  USING (
    auth.uid() = teacher_id OR
    auth.uid() = school_id OR
    auth.jwt() ->> 'role' = 'admin'
  );

CREATE POLICY "Teachers can create applications"
  ON job_applications
  FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = teacher_id AND
    EXISTS (
      SELECT 1 FROM jobs 
      WHERE jobs.id = job_id 
      AND jobs.status = 'active'
    )
  );

CREATE POLICY "Schools can update applications"
  ON job_applications
  FOR UPDATE
  TO authenticated
  USING (
    auth.uid() = school_id OR
    auth.jwt() ->> 'role' = 'admin'
  );

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_job_applications_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for updating updated_at
CREATE TRIGGER update_job_applications_updated_at
  BEFORE UPDATE ON job_applications
  FOR EACH ROW
  EXECUTE FUNCTION update_job_applications_updated_at();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_job_applications_job_id ON job_applications(job_id);
CREATE INDEX IF NOT EXISTS idx_job_applications_teacher_id ON job_applications(teacher_id);
CREATE INDEX IF NOT EXISTS idx_job_applications_school_id ON job_applications(school_id);
CREATE INDEX IF NOT EXISTS idx_job_applications_status ON job_applications(status);