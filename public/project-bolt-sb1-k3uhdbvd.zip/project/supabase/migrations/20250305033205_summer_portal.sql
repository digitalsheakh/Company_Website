-- Add work_date column to jobs table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.columns 
    WHERE table_name = 'jobs' AND column_name = 'work_date'
  ) THEN
    ALTER TABLE jobs
    ADD COLUMN work_date timestamptz NOT NULL DEFAULT now();
  END IF;
END $$;

-- Add index for better performance if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_indexes
    WHERE tablename = 'jobs' AND indexname = 'idx_jobs_work_date'
  ) THEN
    CREATE INDEX idx_jobs_work_date ON jobs(work_date);
  END IF;
END $$;