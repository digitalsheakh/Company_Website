/*
  # Update Schema with Email Fields

  1. Changes
    - Add email column to schools and teachers tables
    - Add email column with proper NULL handling
    - Update RLS policies
    - Add triggers for updated_at timestamp
  
  2. Security
    - Drop existing policies before recreating them
    - Enable RLS on all tables
*/

-- Drop existing policies first
DO $$ 
BEGIN
    -- Drop school policies if they exist
    DROP POLICY IF EXISTS "Schools can view own profile" ON schools;
    DROP POLICY IF EXISTS "Schools can update own profile" ON schools;
    DROP POLICY IF EXISTS "Schools can insert own profile" ON schools;
    
    -- Drop teacher policies if they exist
    DROP POLICY IF EXISTS "Teachers can view own profile" ON teachers;
    DROP POLICY IF EXISTS "Teachers can update own profile" ON teachers;
    DROP POLICY IF EXISTS "Teachers can insert own profile" ON teachers;
END $$;

-- Create or update schools table
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'schools') THEN
        CREATE TABLE schools (
            id uuid PRIMARY KEY REFERENCES auth.users(id),
            name text NOT NULL,
            email text NOT NULL UNIQUE,
            phone text,
            position text NOT NULL,
            type text NOT NULL,
            location text NOT NULL,
            status text NOT NULL DEFAULT 'pending',
            created_at timestamptz DEFAULT now(),
            updated_at timestamptz DEFAULT now()
        );
    ELSE
        -- Add email column if it doesn't exist (with proper NULL handling)
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'schools' AND column_name = 'email') THEN
            -- First add the column as nullable
            ALTER TABLE schools ADD COLUMN email text;
            
            -- Update existing rows with email from auth.users
            UPDATE schools s 
            SET email = (
                SELECT email 
                FROM auth.users 
                WHERE auth.users.id = s.id
            );
            
            -- Now make it NOT NULL and UNIQUE
            ALTER TABLE schools ALTER COLUMN email SET NOT NULL;
            ALTER TABLE schools ADD CONSTRAINT schools_email_unique UNIQUE (email);
        END IF;
    END IF;
END $$;

-- Create or update teachers table
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'teachers') THEN
        CREATE TABLE teachers (
            id uuid PRIMARY KEY REFERENCES auth.users(id),
            email text NOT NULL UNIQUE,
            first_name text NOT NULL,
            last_name text NOT NULL,
            phone text,
            qualifications text,
            subjects text[],
            experience text,
            status text NOT NULL DEFAULT 'pending',
            created_at timestamptz DEFAULT now(),
            updated_at timestamptz DEFAULT now()
        );
    ELSE
        -- Add email column if it doesn't exist (with proper NULL handling)
        IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'teachers' AND column_name = 'email') THEN
            -- First add the column as nullable
            ALTER TABLE teachers ADD COLUMN email text;
            
            -- Update existing rows with email from auth.users
            UPDATE teachers t 
            SET email = (
                SELECT email 
                FROM auth.users 
                WHERE auth.users.id = t.id
            );
            
            -- Now make it NOT NULL and UNIQUE
            ALTER TABLE teachers ALTER COLUMN email SET NOT NULL;
            ALTER TABLE teachers ADD CONSTRAINT teachers_email_unique UNIQUE (email);
        END IF;
    END IF;
END $$;

-- Enable RLS
ALTER TABLE schools ENABLE ROW LEVEL SECURITY;
ALTER TABLE teachers ENABLE ROW LEVEL SECURITY;

-- Create new policies for schools
CREATE POLICY "Schools can view own profile"
    ON schools
    FOR SELECT
    TO authenticated
    USING (auth.uid() = id);

CREATE POLICY "Schools can update own profile"
    ON schools
    FOR UPDATE
    TO authenticated
    USING (auth.uid() = id);

CREATE POLICY "Schools can insert own profile"
    ON schools
    FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = id);

-- Create new policies for teachers
CREATE POLICY "Teachers can view own profile"
    ON teachers
    FOR SELECT
    TO authenticated
    USING (auth.uid() = id);

CREATE POLICY "Teachers can update own profile"
    ON teachers
    FOR UPDATE
    TO authenticated
    USING (auth.uid() = id);

CREATE POLICY "Teachers can insert own profile"
    ON teachers
    FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = id);

-- Create or replace function for updating timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Drop existing triggers if they exist and create new ones
DROP TRIGGER IF EXISTS update_schools_updated_at ON schools;
DROP TRIGGER IF EXISTS update_teachers_updated_at ON teachers;

CREATE TRIGGER update_schools_updated_at
    BEFORE UPDATE ON schools
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_teachers_updated_at
    BEFORE UPDATE ON teachers
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();