/*
  # Add Documents Table and Update Teachers Table

  1. New Tables
    - `documents`
      - `id` (uuid, primary key)
      - `teacher_id` (uuid, foreign key to teachers)
      - `type` (text) - Type of document (identity, dbs, ni_number, cv)
      - `file_url` (text) - URL to the stored document
      - `status` (text) - Document verification status (pending, verified, rejected)
      - `notes` (text) - Admin notes on verification
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
      - `verified_at` (timestamptz)
      - `verified_by` (uuid) - Admin who verified the document

  2. Changes
    - Add verification fields to teachers table
    - Add document type enum
    - Add document status enum

  3. Security
    - Enable RLS on documents table
    - Add policies for document access
*/

-- Create document type enum
CREATE TYPE document_type AS ENUM (
  'identity',
  'dbs',
  'ni_number',
  'cv'
);

-- Create document status enum
CREATE TYPE document_status AS ENUM (
  'pending',
  'verified',
  'rejected'
);

-- Create documents table
CREATE TABLE IF NOT EXISTS documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  teacher_id uuid REFERENCES teachers(id) ON DELETE CASCADE,
  type document_type NOT NULL,
  file_url text NOT NULL,
  status document_status NOT NULL DEFAULT 'pending',
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  verified_at timestamptz,
  verified_by uuid REFERENCES auth.users(id)
);

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_documents_teacher_id ON documents(teacher_id);
CREATE INDEX IF NOT EXISTS idx_documents_status ON documents(status);
CREATE INDEX IF NOT EXISTS idx_documents_type ON documents(type);

-- Enable RLS
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;

-- Policies for documents table
CREATE POLICY "Teachers can view own documents"
  ON documents
  FOR SELECT
  TO authenticated
  USING (auth.uid() = teacher_id);

CREATE POLICY "Teachers can upload own documents"
  ON documents
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = teacher_id);

CREATE POLICY "Admins can view all documents"
  ON documents
  FOR ALL
  TO authenticated
  USING ((auth.jwt() ->> 'role'::text) = 'admin'::text);

-- Add verification trigger to update timestamps
CREATE OR REPLACE FUNCTION update_document_verified_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.status = 'verified' AND OLD.status != 'verified' THEN
    NEW.verified_at = now();
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_document_verified_timestamp
  BEFORE UPDATE ON documents
  FOR EACH ROW
  EXECUTE FUNCTION update_document_verified_timestamp();

-- Add updated_at trigger
CREATE TRIGGER update_documents_updated_at
  BEFORE UPDATE ON documents
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();