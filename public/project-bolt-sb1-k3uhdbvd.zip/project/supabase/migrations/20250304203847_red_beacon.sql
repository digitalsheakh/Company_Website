/*
  # Create teachers table and policies

  1. New Tables
    - `teachers`
      - `id` (uuid, primary key)
      - `first_name` (text)
      - `last_name` (text)
      - `phone` (text, nullable)
      - `qualifications` (text, nullable)
      - `subjects` (text array, nullable)
      - `experience` (text, nullable)
      - `status` (text, default: 'pending')
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `teachers` table
    - Add policies for:
      - Teachers can view and update their own profile
      - Teachers can insert their own profile
*/

-- Create teachers table
CREATE TABLE IF NOT EXISTS teachers (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  first_name text NOT NULL,
  last_name text NOT NULL,
  phone text,
  qualifications text,
  subjects text[],
  experience text,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE teachers ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist and create new ones
DO $$ 
BEGIN
  -- Drop existing policies
  DROP POLICY IF EXISTS "Teachers can view own profile" ON teachers;
  DROP POLICY IF EXISTS "Teachers can update own profile" ON teachers;
  DROP POLICY IF EXISTS "Teachers can insert own profile" ON teachers;
  
  -- Create new policies
  CREATE POLICY "Teachers can view own profile"
    ON teachers
    FOR SELECT
    TO authenticated
    USING (auth.uid() = id);

  CREATE POLICY "Teachers can update own profile"
    ON teachers
    FOR UPDATE
    TO authenticated
    USING (auth.uid() = id);

  CREATE POLICY "Teachers can insert own profile"
    ON teachers
    FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = id);
END $$;

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Drop existing trigger if it exists and create new one
DROP TRIGGER IF EXISTS update_teachers_updated_at ON teachers;
CREATE TRIGGER update_teachers_updated_at
  BEFORE UPDATE ON teachers
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();