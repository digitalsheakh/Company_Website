/*
  # Add Admin Job Policies

  1. Changes
    - Add admin policies for jobs table
    - Allow admins to view and manage all jobs
    - Add policy for public to view active jobs
    - Add policy for schools to view their own jobs

  2. Security
    - Maintain existing RLS
    - Add specific admin policies
*/

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Admins can view all jobs" ON jobs;
  DROP POLICY IF EXISTS "Admins can manage all jobs" ON jobs;
  DROP POLICY IF EXISTS "Public can view active jobs" ON jobs;
END $$;

-- Create admin policies for jobs
CREATE POLICY "Admins can view all jobs"
  ON jobs
  FOR SELECT
  TO authenticated
  USING (
    auth.jwt() ->> 'role' = 'admin' OR
    auth.uid() = school_id
  );

CREATE POLICY "Admins can manage all jobs"
  ON jobs
  FOR ALL
  TO authenticated
  USING (auth.jwt() ->> 'role' = 'admin')
  WITH CHECK (auth.jwt() ->> 'role' = 'admin');

-- Allow public to view active jobs
CREATE POLICY "Public can view active jobs"
  ON jobs
  FOR SELECT
  TO anon, authenticated
  USING (status = 'active');