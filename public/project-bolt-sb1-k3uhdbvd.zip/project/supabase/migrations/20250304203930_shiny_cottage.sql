/*
  # Add jobs table and relationships

  1. New Tables
    - `jobs`
      - `id` (uuid, primary key)
      - `school_id` (uuid, foreign key to schools)
      - `title` (text)
      - `description` (text)
      - `type` (text)
      - `salary_range` (text)
      - `location` (text)
      - `status` (text)
      - `applications` (integer)
      - `posted_at` (timestamptz)
      - `expires_at` (timestamptz)
      - `payment_amount` (text)
      - `payment_status` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `jobs` table
    - Add policies for:
      - Schools can view and manage their own jobs
      - Public can view active jobs
*/

-- Create jobs table
CREATE TABLE IF NOT EXISTS jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id uuid REFERENCES schools(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  type text NOT NULL,
  salary_range text,
  location text,
  status text NOT NULL DEFAULT 'pending_approval',
  applications integer DEFAULT 0,
  posted_at timestamptz DEFAULT now(),
  expires_at timestamptz,
  payment_amount text,
  payment_status text DEFAULT 'unpaid',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  
  CONSTRAINT valid_status CHECK (status IN ('pending_approval', 'active', 'completed', 'rejected')),
  CONSTRAINT valid_payment_status CHECK (payment_status IN ('unpaid', 'pending', 'paid'))
);

-- Enable RLS
ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;

-- Create policies for jobs
DO $$ 
BEGIN
  -- Drop existing policies if they exist
  DROP POLICY IF EXISTS "Schools can view own jobs" ON jobs;
  DROP POLICY IF EXISTS "Schools can insert own jobs" ON jobs;
  DROP POLICY IF EXISTS "Schools can update own jobs" ON jobs;
  DROP POLICY IF EXISTS "Public can view active jobs" ON jobs;
  
  -- Create new policies
  CREATE POLICY "Schools can view own jobs"
    ON jobs
    FOR SELECT
    TO authenticated
    USING (
      auth.uid() = school_id OR
      auth.jwt() ->> 'is_admin' = 'true'
    );

  CREATE POLICY "Schools can insert own jobs"
    ON jobs
    FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = school_id);

  CREATE POLICY "Schools can update own jobs"
    ON jobs
    FOR UPDATE
    TO authenticated
    USING (
      auth.uid() = school_id OR
      auth.jwt() ->> 'is_admin' = 'true'
    );

  CREATE POLICY "Public can view active jobs"
    ON jobs
    FOR SELECT
    TO anon
    USING (status = 'active');
END $$;

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_jobs_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for updating updated_at
DROP TRIGGER IF EXISTS update_jobs_updated_at ON jobs;
CREATE TRIGGER update_jobs_updated_at
  BEFORE UPDATE ON jobs
  FOR EACH ROW
  EXECUTE FUNCTION update_jobs_updated_at();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_jobs_school_id ON jobs(school_id);
CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
CREATE INDEX IF NOT EXISTS idx_jobs_posted_at ON jobs(posted_at);