/*
  # Authentication and User Management Schema

  1. New Tables
    - teachers
      - id (uuid, primary key, references auth.users)
      - first_name (text)
      - last_name (text)
      - phone (text)
      - qualifications (text)
      - subjects (text[])
      - experience (text)
      - status (text)
      - created_at (timestamptz)
      - updated_at (timestamptz)

    - schools
      - id (uuid, primary key, references auth.users)
      - name (text)
      - position (text)
      - type (text)
      - location (text)
      - status (text)
      - created_at (timestamptz)
      - updated_at (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Teachers table
CREATE TABLE IF NOT EXISTS teachers (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  first_name text NOT NULL,
  last_name text NOT NULL,
  phone text,
  qualifications text,
  subjects text[],
  experience text,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Schools table
CREATE TABLE IF NOT EXISTS schools (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  name text NOT NULL,
  position text NOT NULL,
  type text NOT NULL,
  location text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE teachers ENABLE ROW LEVEL SECURITY;
ALTER TABLE schools ENABLE ROW LEVEL SECURITY;

-- Policies for teachers
CREATE POLICY "Teachers can view own profile"
  ON teachers
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Teachers can update own profile"
  ON teachers
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Policies for schools
CREATE POLICY "Schools can view own profile"
  ON schools
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Schools can update own profile"
  ON schools
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Admin policies (using a custom claim 'is_admin')
CREATE POLICY "Admins can view all teachers"
  ON teachers
  FOR SELECT
  TO authenticated
  USING (auth.jwt() ->> 'is_admin' = 'true');

CREATE POLICY "Admins can update all teachers"
  ON teachers
  FOR UPDATE
  TO authenticated
  USING (auth.jwt() ->> 'is_admin' = 'true');

CREATE POLICY "Admins can view all schools"
  ON schools
  FOR SELECT
  TO authenticated
  USING (auth.jwt() ->> 'is_admin' = 'true');

CREATE POLICY "Admins can update all schools"
  ON schools
  FOR UPDATE
  TO authenticated
  USING (auth.jwt() ->> 'is_admin' = 'true');