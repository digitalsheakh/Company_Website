/*
  # Add Admin Policies with Existence Check

  1. Changes
    - Add admin policies to view all data in teachers and schools tables
    - Add admin policies to update all data in teachers and schools tables
    - Check for existing policies before creating new ones

  2. Security
    - Policies check for admin role in JWT claims
    - Maintains existing RLS policies
*/

DO $$ 
BEGIN
  -- Drop existing policies if they exist
  DROP POLICY IF EXISTS "Admins can view all teachers" ON teachers;
  DROP POLICY IF EXISTS "Admins can update all teachers" ON teachers;
  DROP POLICY IF EXISTS "Admins can view all schools" ON schools;
  DROP POLICY IF EXISTS "Admins can update all schools" ON schools;
  
  -- Create new policies
  CREATE POLICY "Admins can view all teachers"
    ON teachers
    FOR SELECT
    TO authenticated
    USING (
      auth.jwt() ->> 'role' = 'admin' OR
      auth.uid() = id
    );

  CREATE POLICY "Admins can update all teachers"
    ON teachers
    FOR UPDATE
    TO authenticated
    USING (
      auth.jwt() ->> 'role' = 'admin' OR
      auth.uid() = id
    );

  CREATE POLICY "Admins can view all schools"
    ON schools
    FOR SELECT
    TO authenticated
    USING (
      auth.jwt() ->> 'role' = 'admin' OR
      auth.uid() = id
    );

  CREATE POLICY "Admins can update all schools"
    ON schools
    FOR UPDATE
    TO authenticated
    USING (
      auth.jwt() ->> 'role' = 'admin' OR
      auth.uid() = id
    );
END $$;