/*
  # Add work date to jobs table

  1. Changes
    - Add work_date column to jobs table
    - Make work_date required for all jobs
    - Add default value as current date
*/

-- Add work_date column to jobs table
ALTER TABLE jobs
ADD COLUMN IF NOT EXISTS work_date timestamptz NOT NULL DEFAULT now();

-- Add index for better performance
CREATE INDEX IF NOT EXISTS idx_jobs_work_date ON jobs(work_date);