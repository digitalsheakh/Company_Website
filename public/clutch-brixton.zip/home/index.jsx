import React from "react";
import { Navbar2 } from "./components/Navbar2";
import { Header5 } from "./components/Header5";
import { Layout18 } from "./components/Layout18";
import { Layout239 } from "./components/Layout239";
import { Layout215 } from "./components/Layout215";
import { Cta31 } from "./components/Cta31";
import { Testimonial14 } from "./components/Testimonial14";
import { Cta25 } from "./components/Cta25";
import { Blog40 } from "./components/Blog40";
import { Contact13 } from "./components/Contact13";
import { Footer2 } from "./components/Footer2";

export default function Page() {
  return (
    <div>
      <Navbar2 />
      <Header5 />
      <Layout18 />
      <Layout239 />
      <Layout215 />
      <Cta31 />
      <Testimonial14 />
      <Cta25 />
      <Blog40 />
      <Contact13 />
      <Footer2 />
    </div>
  );
}
