import React from "react";
import { Navbar2 } from "./components/Navbar2";
import { Header50 } from "./components/Header50";
import { Header26 } from "./components/Header26";
import { Contact14 } from "./components/Contact14";
import { Faq4 } from "./components/Faq4";
import { Cta3 } from "./components/Cta3";
import { Footer2 } from "./components/Footer2";

export default function Page() {
  return (
    <div>
      <Navbar2 />
      <Header50 />
      <Header26 />
      <Contact14 />
      <Faq4 />
      <Cta3 />
      <Footer2 />
    </div>
  );
}
