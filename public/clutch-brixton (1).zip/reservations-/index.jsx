import React from "react";
import { Navbar2 } from "./components/Navbar2";
import { Header62 } from "./components/Header62";
import { Cta4 } from "./components/Cta4";
import { Testimonial1 } from "./components/Testimonial1";
import { Contact23 } from "./components/Contact23";
import { Footer2 } from "./components/Footer2";

export default function Page() {
  return (
    <div>
      <Navbar2 />
      <Header62 />
      <Cta4 />
      <Testimonial1 />
      <Contact23 />
      <Footer2 />
    </div>
  );
}
