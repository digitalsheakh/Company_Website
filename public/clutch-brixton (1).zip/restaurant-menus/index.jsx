import React from "react";
import { Navbar2 } from "./components/Navbar2";
import { Header47 } from "./components/Header47";
import { Layout3 } from "./components/Layout3";
import { Layout90 } from "./components/Layout90";
import { Layout3_1 } from "./components/Layout3_1";
import { Layout12 } from "./components/Layout12";
import { Cta1 } from "./components/Cta1";
import { Footer2 } from "./components/Footer2";

export default function Page() {
  return (
    <div>
      <Navbar2 />
      <Header47 />
      <Layout3 />
      <Layout90 />
      <Layout3_1 />
      <Layout12 />
      <Cta1 />
      <Footer2 />
    </div>
  );
}
